-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: PublicTransportationDatabaseSystem
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accident`
--

DROP TABLE IF EXISTS `accident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accident` (
  `accident_id` int NOT NULL,
  `vehicle_id` int NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`accident_id`),
  KEY `fk_vehicle_id` (`vehicle_id`),
  CONSTRAINT `fk_vehicle_id` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`vehicle_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accident`
--

LOCK TABLES `accident` WRITE;
/*!40000 ALTER TABLE `accident` DISABLE KEYS */;
INSERT INTO `accident` VALUES (1,1,'Car hit a tree','2023-05-21'),(2,2,'Bike skidded on wet road','2023-05-22'),(3,3,'Truck collided with another truck','2023-05-23'),(4,4,'Bus ran over a pedestrian','2023-05-24'),(5,5,'Motorcycle crashed into a wall','2023-05-25'),(6,6,'Van rolled over on a hill','2023-05-26'),(7,7,'SUV hit a deer','2023-05-27'),(8,8,'Taxi rear-ended by a car','2023-05-28'),(9,9,'Limo caught fire','2023-05-29'),(10,10,'Jeep fell into a ditch','2023-05-30'),(11,11,'Pickup truck hit by a train','2023-05-31'),(12,12,'Sedan ran a red light and hit a bus','2023-06-01'),(13,13,'Convertible flipped over on a bridge','2023-06-02'),(14,14,'Hatchback hit a pole','2023-06-03'),(15,15,'Coupe slid on ice and hit a fence','2023-06-04'),(16,16,'Minivan hit by a falling tree','2023-06-05'),(17,17,'Sports car hit a speed bump and lost control','2023-06-06'),(18,18,'Wagon hit a pothole and damaged the tire','2023-06-07'),(19,19,'Crossover ran out of gas and stalled on the highway','2023-06-08'),(20,20,'Hybrid car electrocuted by a lightning strike','2023-06-09'),(21,21,'Electric car exploded due to a faulty battery','2023-06-10'),(22,22,'Muscle car hit a cow','2023-06-11'),(23,23,'Classic car stolen by thieves','2023-06-12'),(24,24,'Luxury car vandalized by protesters','2023-06-13'),(25,25,'Compact car crushed by a falling rock','2023-06-14'),(27,26,'Subcompact car hit by a hailstorm','2023-06-15'),(28,27,'Midsize car flooded by a heavy rain','2023-06-16'),(29,28,'Full-size car scratched by a cat','2023-06-17'),(30,29,'Station wagon hit by a snowball','2023-06-18'),(31,30,'Hardtop car dented by a golf ball','2023-06-19'),(32,31,'Soft-top car torn by a bird','2023-06-20'),(33,32,'Off-road car stuck in mud','2023-06-21'),(34,33,'All-wheel drive car skidded on gravel','2023-06-22'),(35,34,'Front-wheel drive car spun out on sand','2023-06-23'),(36,35,'Rear-wheel drive car drifted on oil','2023-06-24'),(37,36,'Four-wheel drive car rolled over on a hill','2023-06-25'),(39,37,'Two-wheel drive car hit a bump and flew off the road','2023-06-26'),(40,38,'Six-wheel drive car hit a landmine and exploded','2023-06-27'),(41,39,'Eight-wheel drive car hit a sinkhole and disappeared','2023-06-28'),(42,40,'Ten-wheel drive car hit a wall and split in half','2023-06-29'),(43,41,'Twelve-wheel drive car hit a bridge and collapsed','2023-06-30'),(44,42,'Fourteen-wheel drive car hit a mountain and crumbled','2023-07-01'),(45,43,'Sixteen-wheel drive car hit a lake and sank','2023-07-02');
/*!40000 ALTER TABLE `accident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administration`
--

DROP TABLE IF EXISTS `administration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administration` (
  `admin_id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `driver_id` int DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `fk_driver_id_Administration` (`driver_id`),
  CONSTRAINT `fk_driver_id_Administration` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administration`
--

LOCK TABLES `administration` WRITE;
/*!40000 ALTER TABLE `administration` DISABLE KEYS */;
INSERT INTO `administration` VALUES (1,'admin1','password1',1),(2,'admin2','password2',2),(3,'admin3','password3',3),(4,'admin4','password4',4),(5,'admin5','password5',5),(6,'admin6','password6',6),(7,'admin7','password7',7),(8,'admin8','password8',8),(9,'admin9','password9',9),(10,'admin10','password10',10);
/*!40000 ALTER TABLE `administration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delay`
--

DROP TABLE IF EXISTS `delay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delay` (
  `delay_id` int NOT NULL,
  `trip_id` int NOT NULL,
  `duration` int NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`delay_id`),
  KEY `fk_trip_id` (`trip_id`),
  CONSTRAINT `fk_trip_id` FOREIGN KEY (`trip_id`) REFERENCES `schedule` (`schedule_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delay`
--

LOCK TABLES `delay` WRITE;
/*!40000 ALTER TABLE `delay` DISABLE KEYS */;
INSERT INTO `delay` VALUES (1,1,15,'Traffic congestion'),(2,2,10,'Mechanical issue'),(3,3,30,'Inclement weather'),(4,4,20,'Passenger late boarding'),(5,5,25,'Security check delay'),(6,6,5,'Air traffic control delay'),(7,7,15,'Gate change'),(8,8,10,'Crew rest requirement'),(9,9,15,'Maintenance issue'),(10,10,20,'Late arrival of inbound aircraft'),(11,11,15,'Traffic congestion'),(12,12,10,'Mechanical issue'),(13,13,30,'Inclement weather'),(14,14,20,'Passenger late boarding'),(15,15,25,'Security check delay'),(16,16,5,'Air traffic control delay'),(17,17,15,'Gate change'),(18,18,10,'Crew rest requirement'),(19,19,15,'Maintenance issue'),(20,20,20,'Late arrival of inbound aircraft'),(21,21,5,'Traffic congestion'),(22,22,10,'Mechanical issue'),(23,23,30,'Inclement weather'),(24,24,20,'Passenger late boarding'),(25,25,25,'Security check delay'),(26,26,5,'Air traffic control delay'),(27,27,15,'Gate change'),(28,28,10,'Crew rest requirement'),(29,29,15,'Maintenance issue'),(30,30,20,'Late arrival of inbound aircraft'),(31,31,15,'Traffic congestion'),(32,32,10,'Mechanical issue'),(33,33,30,'Inclement weather'),(34,34,20,'Passenger late boarding'),(35,35,25,'Security check delay'),(36,36,5,'Air traffic control delay'),(37,37,15,'Gate change'),(38,38,10,'Crew rest requirement'),(39,39,15,'Maintenance issue'),(40,40,20,'Late arrival of inbound aircraft');
/*!40000 ALTER TABLE `delay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `driver` (
  `driver_id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `license_number` varchar(255) NOT NULL,
  `hire_date` date NOT NULL,
  PRIMARY KEY (`driver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driver`
--

LOCK TABLES `driver` WRITE;
/*!40000 ALTER TABLE `driver` DISABLE KEYS */;
INSERT INTO `driver` VALUES (1,'John','Doe','ABC123','2022-01-15'),(2,'Jane','Smith','XYZ789','2022-02-20'),(3,'Michael','Johnson','DEF456','2022-03-10'),(4,'Emily','Williams','GHI789','2022-04-05'),(5,'David','Brown','JKL321','2022-05-12'),(6,'Sarah','Jones','MNO654','2022-06-08'),(7,'Daniel','Miller','PQR987','2022-07-23'),(8,'Olivia','Davis','STU654','2022-08-19'),(9,'James','Anderson','VWX321','2022-09-14'),(10,'Sophia','Wilson','YZA987','2022-10-30'),(11,'Jacob','Taylor','BDC246','2022-11-05'),(12,'Mia','Thomas','EFG579','2022-12-18'),(13,'Ethan','Harris','HIJ864','2023-01-22'),(14,'Ava','Walker','KLM753','2023-02-14'),(15,'Noah','Robinson','OPQ258','2023-03-29'),(16,'Isabella','Green','RST961','2023-04-11'),(17,'Liam','Hall','UVW374','2023-05-05'),(18,'Charlotte','Lee','XYZ185','2023-06-17'),(19,'William','Clark','ABC982','2023-07-09'),(20,'Sophie','Adams','DEF475','2023-08-23'),(21,'Benjamin','Baker','GHI168','2023-09-16'),(22,'Grace','Carter','JKL759','2023-10-28'),(23,'Henry','Cook','MNO342','2023-11-21'),(24,'Scarlett','Bell','PQR835','2023-12-03'),(25,'Alexander','Murphy','STU526','2024-01-08'),(26,'Avery','Turner','VWX219','2024-02-12'),(27,'Daniel','Parker','YZA902','2024-03-25'),(28,'Sofia','Collins','BDC693','2024-04-18'),(29,'Jackson','Evans','EFG486','2024-05-30'),(30,'Amelia','Garcia','HIJ179','2024-06-22'),(31,'Liam','Rodriguez','KLM462','2024-07-15'),(32,'Emily','Wilson','OPQ753','2024-08-28'),(33,'Mason','Anderson','RST946','2024-09-21'),(34,'Ella','Martinez','UVW539','2024-10-04'),(35,'James','Lopez','XYZ222','2024-11-19'),(36,'Evelyn','Adams','ABC915','2024-12-01'),(37,'Oliver','Gonzalez','DEF508','2025-01-06'),(38,'Mia','Hernandez','GHI191','2025-02-10'),(39,'Sebastian','Taylor','JKL784','2025-03-24'),(40,'Avery','Lewis','MNO377','2025-04-17'),(41,'Harper','Hall','PQR970','2025-05-29'),(42,'Benjamin','Young','STU563','2025-06-21'),(43,'Lily','Scott','VWX256','2025-07-03'),(44,'Jacob','Perez','YZA949','2025-08-17'),(45,'Amelia','Turner','BDC532','2025-09-09'),(46,'Ethan','King','EFG225','2025-10-23'),(47,'Charlotte','Baker','HIJ818','2025-11-15'),(48,'Alexander','Garcia','KLM511','2025-12-27'),(49,'Olivia','Thomas','OPQ204','2026-01-20'),(50,'Michael','Robinson','RST897','2026-02-03'),(51,'Sophia','Hall','UVW480','2026-03-17'),(52,'Daniel','Clark','XYZ173','2026-04-09'),(53,'Ava','Adams','ABC866','2026-05-22'),(54,'Logan','Wright','DEF459','2026-06-14'),(55,'Isabella','Lee','GHI142','2026-07-26'),(56,'Jack','Green','JKL735','2026-08-19'),(57,'Emily','Carter','MNO428','2026-09-01'),(58,'Noah','Cook','PQR021','2026-10-15'),(59,'Grace','Bell','STU614','2026-11-08'),(60,'William','Murphy','VWX207','2026-12-21'),(61,'Emma','Harris','YZA872','2027-01-14'),(62,'Liam','Allen','BDC565','2027-02-26'),(63,'Olivia','Rivera','EFG258','2027-03-20'),(64,'Noah','Gomez','HIJ941','2027-04-03'),(65,'Isabella','Cruz','KLM534','2027-05-16'),(66,'Sophia','Bailey','OPQ227','2027-06-08'),(67,'Mia','Howard','RST820','2027-07-22'),(68,'Lucas','Long','UVW413','2027-08-15'),(69,'Ava','Sanders','XYZ106','2027-09-27'),(70,'Henry','Foster','ABC799','2027-10-20'),(71,'Charlotte','Cox','DEF382','2027-11-02'),(72,'Logan','Reed','GHI975','2027-12-16'),(73,'Amelia','Phillips','JKL568','2028-01-08'),(74,'Mason','Simmons','MNO161','2028-02-21'),(75,'Harper','Perry','PQR754','2028-03-15'),(76,'Elijah','Butler','STU347','2028-04-28'),(77,'Evelyn','Hawkins','VWX040','2028-05-20'),(78,'Michael','Bryant','YZA733','2028-06-02'),(79,'Emily','Alexander','BDC426','2028-07-16'),(80,'Daniel','Russell','EFG119','2028-08-09'),(81,'Sofia','Griffin','HIJ802','2028-09-21'),(82,'Avery','Diaz','KLM395','2028-10-14'),(83,'William','Hayes','OPQ988','2028-11-27'),(84,'Scarlett','Myers','RST581','2028-12-19'),(85,'James','Ford','UVW274','2029-01-31'),(86,'Victoria','Hamilton','XYZ967','2029-02-23'),(87,'Benjamin','Sullivan','ABC660','2029-04-08'),(88,'Luna','Barnes','DEF253','2029-05-01'),(89,'Sebastian','Fisher','GHI946','2029-06-15'),(90,'Abigail','Coleman','JKL539','2029-07-07'),(91,'Jack','Parker','MNO232','2029-08-20'),(92,'Aria','Wright','PQR925','2029-09-12'),(93,'Christopher','Morris','STU518','2029-10-26'),(94,'Addison','Powell','VWX211','2029-11-18'),(95,'Wyatt','Baker','YZA904','2029-12-30'),(96,'Elizabeth','Cooper','BDC597','2030-01-22'),(97,'Ryan','Jenkins','EFG280','2030-03-07'),(98,'Layla','Foster','HIJ973','2030-03-30'),(99,'Owen','Gonzalez','KLM566','2030-05-12'),(100,'Camila','Ross','OPQ259','2030-06-04'),(101,'Ethan','Hernandez','RST752','2030-06-26'),(102,'Nora','King','UVW445','2030-07-19'),(103,'Alexander','Wood','XYZ138','2030-08-31'),(104,'Grace','Mitchell','ABC731','2030-09-23'),(105,'Carter','Adams','DEF424','2030-11-06'),(106,'Hazel','Campbell','GHI117','2030-12-29'),(107,'Gabriel','Turner','JKL710','2031-01-21'),(108,'Stella','Lopez','MNO403','2031-03-06'),(109,'Matthew','Hill','PQR096','2031-03-29'),(110,'Aubrey','Ward','STU789','2031-05-12'),(111,'David','Simmons','VWX482','2031-06-04'),(112,'Savannah','Reed','YZA175','2031-07-17'),(113,'Joseph','Fisher','BDC868','2031-08-09'),(114,'Penelope','Barnes','EFG561','2031-09-23'),(115,'Leo','Cruz','HIJ254','2031-10-16'),(116,'Naomi','Hughes','KLM957','2031-11-08'),(117,'Elijah','Parker','PQS360','2031-12-21'),(118,'Audrey','Collins','TUV653','2032-01-13'),(119,'Owen','Butler','WXY246','2032-03-02'),(120,'Scarlett','Baker','ZAB939','2032-04-16'),(121,'Lucas','Gonzalez','CDE522','2032-05-09'),(122,'Madelyn','Foster','FGH215','2032-06-22'),(123,'Wyatt','Morris','IJK808','2032-07-14'),(124,'Chloe','Russell','LMN503','2032-09-01'),(125,'Daniel','Sullivan','PQR196','2032-10-15'),(126,'Harper','Ross','STU889','2032-11-07'),(127,'Isaac','Cole','VWX482','2032-12-20'),(128,'Violet','Henderson','YZA175','2033-01-12'),(129,'Julian','Wells','BDC868','2033-03-01'),(130,'Aria','Bryant','EFG561','2033-04-15'),(131,'Henry','Alexander','HIJ254','2033-05-08'),(132,'Eva','Simmons','KLM957','2033-06-21'),(133,'Ryan','Perez','PQS360','2033-07-13'),(134,'Liam','Carter','TUV653','2033-08-27'),(135,'Leah','Foster','WXY246','2033-10-11'),(136,'Sophia','Baker','ZAB939','2033-11-24'),(137,'Jackson','Gonzalez','CDE522','2033-12-17'),(138,'Lily','Morris','FGH215','2034-01-30'),(139,'Logan','Russell','IJK808','2034-02-22'),(140,'Avery','Sullivan','LMN503','2034-04-11'),(141,'Benjamin','Ross','PQR196','2034-05-25'),(142,'Mia','Henderson','STU889','2034-06-17'),(143,'Caleb','Wells','VWX482','2034-08-05'),(144,'Abigail','Bryant','YZA175','2034-09-19'),(145,'Oliver','Alexander','BDC868','2034-10-13'),(146,'Emily','Simmons','EFG561','2034-11-26'),(147,'Ethan','Perez','HIJ254','2034-12-19'),(148,'Aurora','Carter','KLM957','2035-01-31'),(149,'Jacob','Foster','PQS360','2035-03-15'),(150,'Elizabeth','Baker','TUV653','2035-04-28'),(151,'Mason','Gonzalez','WXY246','2035-06-11'),(152,'Evelyn','Morris','ZAB939','2035-07-25'),(153,'William','Russell','CDE522','2035-08-18'),(154,'Sofia','Sullivan','FGH215','2035-10-01'),(155,'Michael','Ross','IJK808','2035-11-14');
/*!40000 ALTER TABLE `driver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faretype`
--

DROP TABLE IF EXISTS `faretype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faretype` (
  `fare_type_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`fare_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faretype`
--

LOCK TABLES `faretype` WRITE;
/*!40000 ALTER TABLE `faretype` DISABLE KEYS */;
INSERT INTO `faretype` VALUES (1,'Standard','Regular fare',10.00),(2,'Senior','Discounted fare for seniors',7.50),(3,'Student','Discounted fare for students',6.00),(4,'Child','Discounted fare for children',5.00),(5,'Group','Discounted fare for groups',8.00),(6,'Monthly Pass','Unlimited rides for a month',50.00);
/*!40000 ALTER TABLE `faretype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incident`
--

DROP TABLE IF EXISTS `incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incident` (
  `incident_id` int NOT NULL,
  `passenger_id` int DEFAULT NULL,
  `driver_id` int DEFAULT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`incident_id`),
  KEY `fk_passenger_id` (`passenger_id`),
  KEY `fk_driver_id` (`driver_id`),
  CONSTRAINT `fk_driver_id` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_passenger_id` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident`
--

LOCK TABLES `incident` WRITE;
/*!40000 ALTER TABLE `incident` DISABLE KEYS */;
INSERT INTO `incident` VALUES (1,1,1,'Driver took a wrong turn and arrived late','2023-05-01'),(2,2,1,'Passenger spilled coffee in the car','2023-05-02'),(3,1,2,'Driver drove too fast, making the passenger uncomfortable','2023-05-03'),(4,3,3,'Passenger left trash in the car','2023-05-04'),(5,4,3,'Driver did not follow GPS and took longer route','2023-05-05'),(6,2,2,'Passenger was rude to the driver','2023-05-06'),(7,1,4,'Driver played loud music despite passenger request to lower volume','2023-05-07'),(8,5,4,'Passenger smoked inside the car','2023-05-08'),(9,4,1,'Driver was texting while driving','2023-05-09'),(10,3,2,'Passenger did not wear a seatbelt and refused to comply','2023-05-10'),(11,1,2,'Minor fender bender','2023-05-01'),(12,3,1,'Flat tire on highway','2023-05-02'),(13,4,2,'Rear-ended at stoplight','2023-05-04'),(14,2,3,'Side-swiped on freeway','2023-05-05'),(15,1,4,'Hit and run in parking lot','2023-05-06'),(16,3,5,'Broken windshield from rock','2023-05-07'),(17,2,4,'Collision with deer','2023-05-08'),(18,5,1,'Rear-ended on highway','2023-05-10'),(19,4,3,'Side-swiped by truck','2023-05-12'),(20,5,2,'Minor accident in intersection','2023-05-15'),(21,6,2,'Rear-ended at stoplight','2023-05-18'),(22,1,7,'Minor dent on bumper','2023-05-19'),(23,8,3,'Side-swiped by another car','2023-05-20'),(24,9,4,'Hit and run while parked','2023-05-21'),(25,5,7,'Minor accident in parking lot','2023-05-22'),(26,2,9,'Collision with another car','2023-05-23'),(27,10,6,'Broken taillight from minor accident','2023-05-24'),(28,7,1,'Flat tire on side of road','2023-05-25'),(29,3,8,'Minor fender bender','2023-05-26'),(30,6,5,'Rear-ended on freeway','2023-05-27'),(31,9,2,'Side-swiped on highway','2023-05-28'),(32,10,4,'Minor accident in intersection','2023-05-29'),(33,1,3,'Hit and run by motorcycle','2023-05-30'),(34,4,5,'Collision with debris on road','2023-06-01'),(35,8,7,'Rear-ended at stoplight','2023-06-02'),(36,2,6,'Minor accident in parking garage','2023-06-03'),(37,7,5,'Side-swiped by another car','2023-06-04'),(38,3,1,'Hit and run while parked','2023-06-05'),(39,10,8,'Collision with parked car','2023-06-06'),(40,9,6,'Minor fender bender','2023-06-07'),(41,5,3,'Flat tire on side of road','2023-06-08'),(42,6,7,'Rear-ended on highway','2023-06-09'),(43,1,9,'Minor accident in intersection','2023-06-10'),(44,4,8,'Collision with another car','2023-06-11'),(45,7,2,'Hit and run by truck','2023-06-12'),(46,8,4,'Minor accident in parking lot','2023-06-13'),(47,2,10,'Side-swiped by another car','2023-06-14'),(48,3,5,'Collision with deer','2023-06-15'),(49,9,1,'Rear-ended at stoplight','2023-06-16'),(50,10,7,'Minor fender bender','2023-06-17'),(51,5,8,'Minor accident in intersection','2023-06-18'),(52,3,6,'Side-swiped by another car','2023-06-19'),(53,2,4,'Hit and run while parked','2023-06-20'),(54,9,7,'Collision with another car','2023-06-21'),(55,1,10,'Rear-ended on highway','2023-06-22'),(56,8,5,'Minor fender bender','2023-06-23'),(57,7,3,'Flat tire on side of road','2023-06-24'),(58,6,1,'Collision with debris on road','2023-06-25'),(59,4,9,'Rear-ended at stoplight','2023-06-26'),(60,10,2,'Side-swiped on highway','2023-06-27'),(61,3,8,'Minor accident inintersection','2023-06-28'),(62,5,1,'Hit and run by motorcycle','2023-06-29'),(63,7,4,'Collision with parked car','2023-06-30'),(64,1,6,'Minor fender bender','2023-07-01'),(65,6,10,'Collision with another car','2023-07-02'),(66,8,2,'Rear-ended on freeway','2023-07-03'),(67,9,3,'Side-swiped by another car','2023-07-04'),(68,2,7,'Minor accident in parking lot','2023-07-05'),(69,4,5,'Rear-ended at stoplight','2023-07-06'),(70,10,1,'Collision with deer','2023-07-07'),(71,3,9,'Hit and run while parked','2023-07-08'),(72,1,4,'Minor accident in intersection','2023-07-09'),(73,6,3,'Side-swiped by another car','2023-07-10'),(74,5,7,'Collision with parked car','2023-07-11'),(75,9,2,'Rear-ended on highway','2023-07-12'),(76,8,10,'Minor fender bender','2023-07-13'),(77,4,6,'Collision with another car','2023-07-14'),(78,7,1,'Side-swiped on freeway','2023-07-15'),(79,2,5,'Minor accident in parking lot','2023-07-16'),(80,3,10,'Hit and run while parked','2023-07-17'),(81,6,8,'Rear-ended at stoplight','2023-07-18'),(82,1,2,'Collision with debris on road','2023-07-19'),(83,10,4,'Minor accident in intersection','2023-07-20'),(84,5,9,'Collision with another car','2023-07-21'),(85,7,2,'Rear-ended on freeway','2023-07-22'),(86,4,1,'Side-swiped by another car','2023-07-23'),(87,2,6,'Minor fender bender','2023-07-24'),(88,3,7,'Hit and run by truck','2023-07-25'),(89,8,9,'Collision with deer','2023-07-26'),(90,1,5,'Minor accident in parking lot','2023-07-27'),(91,6,4,'Side-swiped by another car','2023-07-28'),(92,2,1,'Hit and run while parked','2023-07-29'),(93,8,7,'Minor accident in intersection','2023-07-30'),(94,4,10,'Collision with another car','2023-07-31'),(95,7,5,'Rear-ended at stoplight','2023-08-01'),(96,1,9,'Collision with debris on road','2023-08-02'),(97,3,2,'Minor accident in parking lot','2023-08-03'),(98,5,6,'Hit and run by motorcycle','2023-08-04'),(99,10,8,'Collision with parked car','2023-08-05'),(100,9,3,'Rear-ended on highway','2023-08-06'),(101,6,1,'Side-swiped by anothercar','2023-08-07'),(102,2,7,'Minor fender bender','2023-08-08'),(103,8,4,'Collision with another car','2023-08-09'),(104,5,3,'Rear-ended at stoplight','2023-08-10'),(105,1,10,'Minor accident in intersection','2023-08-11'),(106,9,6,'Side-swiped on highway','2023-08-12'),(107,3,5,'Hit and run while parked','2023-08-13'),(108,7,2,'Collision with debris on road','2023-08-14'),(109,4,9,'Minor fender bender','2023-08-15'),(110,6,10,'Rear-ended on freeway','2023-08-16'),(111,1,4,'Collision with another car','2023-08-17'),(112,8,3,'Side-swiped on freeway','2023-08-18'),(113,2,6,'Minor accident in parking lot','2023-08-19'),(114,5,7,'Hit and run by truck','2023-08-20'),(115,9,1,'Rear-ended at stoplight','2023-08-21'),(116,10,2,'Collision with deer','2023-08-22'),(117,3,8,'Minor accident in intersection','2023-08-23'),(118,1,5,'Side-swiped by another car','2023-08-24'),(119,6,4,'Collision with parked car','2023-08-25'),(120,7,9,'Rear-ended on highway','2023-08-26'),(121,5,10,'Minor fender bender','2023-08-27'),(122,9,2,'Collision with debris on road','2023-08-28'),(123,4,1,'Hit and run while parked','2023-08-29'),(124,8,6,'Minor accident in parking lot','2023-08-30'),(125,2,3,'Side-swiped on highway','2023-08-31'),(126,1,7,'Rear-ended at stoplight','2023-09-01'),(127,6,5,'Collision with another car','2023-09-02'),(128,10,4,'Minor accident in intersection','2023-09-03'),(129,3,9,'Hit and run by motorcycle','2023-09-04'),(130,8,2,'Collision with parked car','2023-09-05'),(131,5,1,'Minor fender bender','2023-09-06'),(132,9,7,'Collision with another car','2023-09-07'),(133,6,3,'Side-swiped on freeway','2023-09-08'),(134,2,10,'Rear-ended on highway','2023-09-09'),(135,8,5,'Minor accident in parking lot','2023-09-10'),(136,4,6,'Hit and run by truck','2023-09-11'),(137,7,9,'Collision with deer','2023-09-12'),(138,1,2,'Rear-ended at stoplight','2023-09-13'),(139,3,8,'Collision with parked car','2023-09-14'),(140,5,10,'Minor accident in intersection','2023-09-15'),(141,9,1,'Side-swiped by another car','2023-09-16'),(142,6,4,'Collision with parked car','2023-09-17'),(143,2,7,'Rear-ended on highway','2023-09-18'),(144,8,3,'Minor fender bender','2023-09-19'),(145,4,9,'Collision with another car','2023-09-20'),(146,7,5,'Side-swiped on freeway','2023-09-21'),(147,1,6,'Hit and run while parked','2023-09-22'),(148,3,2,'Minor accident in intersection','2023-09-23'),(149,5,8,'Rear-ended at stoplight','2023-09-24'),(150,9,10,'Collision with debris on road','2023-09-25'),(151,4,1,'Minor fender bender','2023-09-26'),(152,7,3,'Collision with another car','2023-09-27'),(153,2,5,'Side-swiped on freeway','2023-09-28'),(154,6,9,'Hit and run while parked','2023-09-29'),(155,1,4,'Minor accident in intersection','2023-09-30');
/*!40000 ALTER TABLE `incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenancerecord`
--

DROP TABLE IF EXISTS `maintenancerecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenancerecord` (
  `maintenance_id` int NOT NULL,
  `vehicle_id` int NOT NULL,
  `driver_id` int NOT NULL,
  `maintenance_date` date NOT NULL,
  `description` text,
  `cost` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`maintenance_id`),
  KEY `fk_vehicle_id_MaintenanceRecord` (`vehicle_id`),
  KEY `fk_driver_id_MaintenanceRecord` (`driver_id`),
  CONSTRAINT `fk_driver_id_MaintenanceRecord` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vehicle_id_MaintenanceRecord` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`vehicle_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenancerecord`
--

LOCK TABLES `maintenancerecord` WRITE;
/*!40000 ALTER TABLE `maintenancerecord` DISABLE KEYS */;
INSERT INTO `maintenancerecord` VALUES (1,5,7,'2022-01-15','Oil change and tire rotation',65.99),(2,8,1,'2022-02-05','Brake pad replacement',145.75),(3,2,9,'2022-03-20','Battery replacement',225.50),(4,4,3,'2022-04-10','Alignment check',79.99),(5,1,4,'2022-05-15','Transmission service',125.00),(6,3,6,'2022-06-05','Coolant flush',99.99),(7,6,2,'2022-07-10','Air filter replacement',35.50),(8,10,5,'2022-08-15','Timing belt replacement',399.99),(9,9,9,'2022-09-20','Suspension inspection',120.00),(10,10,10,'2022-10-25','Battery replacement',180.00),(11,11,11,'2022-11-30','Air conditioning repair',280.00),(12,12,12,'2022-12-05','Fuel system cleaning',150.00),(13,13,13,'2023-01-10','Wheel alignment',100.00),(14,14,14,'2023-02-15','Exhaust system inspection',80.00),(15,15,15,'2023-03-20','Windshield replacement',200.00),(16,16,16,'2023-04-25','Radiator repair',180.00),(17,17,17,'2023-05-30','Power steering fluid flush',120.00),(18,18,18,'2023-06-05','Cabin air filter replacement',60.00),(19,19,19,'2023-07-10','Spark plug replacement',80.00),(20,20,20,'2023-08-15','Timing belt replacement',350.00),(21,21,21,'2023-09-20','Engine diagnostics',100.00),(22,22,22,'2023-10-25','Steering linkage inspection',120.00),(23,23,23,'2023-11-30','Brake pad replacement',150.00),(24,24,24,'2023-12-05','Air filter replacement',40.00),(25,25,25,'2024-01-10','Wheel bearing lubrication',80.00),(26,26,26,'2024-02-15','Coolant system flush',120.00),(27,27,27,'2024-03-20','Ignition coil replacement',90.00),(28,28,28,'2024-04-25','Throttle body cleaning',60.00),(29,29,29,'2024-05-30','Emission system check',100.00),(30,30,30,'2024-06-05','Battery maintenance',50.00),(31,31,31,'2024-07-10','Fuel injector cleaning',80.00),(32,1,1,'2022-01-10','Routine maintenance',150.00),(33,2,2,'2022-02-15','Engine checkup',300.00),(34,3,3,'2022-03-20','Brake replacement',250.00),(35,4,4,'2022-04-25','Tire rotation',100.00),(36,5,5,'2022-05-30','Oil change',80.00),(37,6,6,'2022-06-05','Electrical system repair',400.00),(38,7,7,'2022-07-10','Transmission service',200.00),(39,8,8,'2022-08-15','Cooling system flush',150.00);
/*!40000 ALTER TABLE `maintenancerecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenancetype`
--

DROP TABLE IF EXISTS `maintenancetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenancetype` (
  `maintenance_type_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`maintenance_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenancetype`
--

LOCK TABLES `maintenancetype` WRITE;
/*!40000 ALTER TABLE `maintenancetype` DISABLE KEYS */;
INSERT INTO `maintenancetype` VALUES (1,'Oil change','Routine maintenance to replace engine oil'),(2,'Tire rotation','Routine maintenance to rotate tires for even wear'),(3,'Brake pad replacement','Maintenance to replace worn brake pads'),(4,'Battery replacement','Maintenance to replace a dead or failing battery'),(5,'Alignment check','Maintenance to check and adjust wheel alignment'),(6,'Transmission service','Routine maintenance to replace transmission fluid'),(7,'Coolant flush','Maintenance to flush and replace engine coolant'),(8,'Air filter replacement','Routine maintenance to replace dirty air filter'),(9,'Timing belt replacement','Maintenance to replace worn timing belt'),(10,'Spark plug replacement','Routine maintenance to replace worn spark plugs'),(11,'Fuel filter replacement','Maintenance to replace a clogged fuel filter'),(12,'Power steering fluid flush','Maintenance to flush and replace power steering fluid'),(13,'Radiator replacement','Maintenance to replace a damaged or leaking radiator'),(14,'Wheel bearing replacement','Maintenance to replace worn wheel bearings'),(15,'Suspension repair','Maintenance to repair worn or damaged suspension components'),(16,'Catalytic converter replacement','Maintenance to replace a failed catalytic converter'),(17,'Exhaust system repair','Maintenance to repair leaks or damage in the exhaust system'),(18,'Fuel system cleaning','Maintenance to clean and restore fuel system performance'),(19,'Starter motor replacement','Maintenance to replace a failed starter motor'),(20,'Alternator replacement','Maintenance to replace a failed alternator'),(21,'Ignition coil replacement','Maintenance to replace a failed ignition coil'),(22,'Thermostat replacement','Maintenance to replace a failed thermostat'),(23,'Water pump replacement','Maintenance to replace a failed water pump'),(24,'Drive belt replacement','Maintenance to replace worn or damaged drive belts'),(25,'CV joint replacement','Maintenance to replace worn or damaged CV joints'),(26,'Wheel bearing replacement','Maintenance to replace worn wheel bearings'),(27,'Brake rotor replacement','Maintenance to replace worn brake rotors'),(28,'Shocks and struts replacement','Maintenance to replace worn shocks and struts'),(29,'Engine tune-up','Routine maintenance to optimize engine performance'),(30,'A/C system recharge','Maintenance to recharge and restore A/C system performance'),(31,'Power window repair','Maintenance to repair a failed power window'),(32,'Cabin air filter replacement','Routine maintenance to replace dirty cabin air filter'),(33,'Headlight bulb replacement','Maintenance to replace a burned out headlight bulb'),(34,'Tail light replacement','Maintenance to replace a burned out tail light'),(35,'Windshield wiper blade replacement','Routine maintenance to replace worn windshield wiper blades'),(36,'Transmission repair','Maintenance to repair a damaged or failing transmission'),(37,'Engine rebuild','Maintenance to rebuild a worn or damaged engine'),(38,'Suspension alignment','Maintenance to adjust suspension alignment'),(39,'Fuel injector cleaning','Maintenance to clean and restore fuel injector performance'),(40,'Radiator flush','Maintenanceto flush and replace engine coolant, including radiator');
/*!40000 ALTER TABLE `maintenancetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenancetyperecord`
--

DROP TABLE IF EXISTS `maintenancetyperecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenancetyperecord` (
  `maintenance_id` int NOT NULL,
  `maintenance_type_id` int NOT NULL,
  PRIMARY KEY (`maintenance_id`,`maintenance_type_id`),
  KEY `fk_maintenance_type_id` (`maintenance_type_id`),
  CONSTRAINT `fk_maintenance_id` FOREIGN KEY (`maintenance_id`) REFERENCES `maintenancerecord` (`maintenance_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_maintenance_type_id` FOREIGN KEY (`maintenance_type_id`) REFERENCES `maintenancetype` (`maintenance_type_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenancetyperecord`
--

LOCK TABLES `maintenancetyperecord` WRITE;
/*!40000 ALTER TABLE `maintenancetyperecord` DISABLE KEYS */;
INSERT INTO `maintenancetyperecord` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),(24,24),(25,25),(26,26),(27,27),(28,28),(29,29),(30,30);
/*!40000 ALTER TABLE `maintenancetyperecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passenger` (
  `passenger_id` int NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`passenger_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger`
--

LOCK TABLES `passenger` WRITE;
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
INSERT INTO `passenger` VALUES (1,'John','Doe','john.doe@example.com','1234567890'),(2,'Jane','Smith','jane.smith@example.com','9876543210'),(3,'Michael','Johnson','michael.johnson@example.com','5551234567'),(4,'Emily','Brown','emily.brown@example.com','9998887776'),(5,'Daniel','Davis','daniel.davis@example.com','1231231234'),(6,'Sophia','Taylor','sophia.taylor@example.com','4445556666'),(7,'Oliver','Wilson','oliver.wilson@example.com','7778889999'),(8,'Emma','Clark','emma.clark@example.com','5556667777'),(9,'James','Anderson','james.anderson@example.com','1112223333'),(10,'Ava','Martin','ava.martin@example.com','9990001111'),(11,'William','Thomas','william.thomas@example.com','5551112222'),(12,'Samantha','White','samantha.white@example.com','8889990000'),(13,'Benjamin','Anderson','benjamin.anderson@example.com','4443332222'),(14,'Charlotte','Jackson','charlotte.jackson@example.com','1234567890'),(15,'Ethan','Lee','ethan.lee@example.com','9998887776'),(16,'Olivia','Harris','olivia.harris@example.com','7776665555'),(17,'Liam','Wilson','liam.wilson@example.com','1112223333'),(18,'Isabella','Roberts','isabella.roberts@example.com','5554443333'),(19,'Mason','Taylor','mason.taylor@example.com','2223334444'),(20,'Mia','Anderson','mia.anderson@example.com','9990001111'),(21,'Noah','Walker','noah.walker@example.com','8887776666'),(22,'Amelia','Thompson','amelia.thompson@example.com','3332221111'),(23,'James','Hall','james.hall@example.com','6667778888'),(24,'Sophia','Martin','sophia.martin@example.com','5556667777'),(25,'Alexander','Adams','alexander.adams@example.com','1112223333'),(26,'Ava','Robinson','ava.robinson@example.com','4445556666'),(27,'Elijah','Cook','elijah.cook@example.com','7778889999'),(28,'Emily','Hill','emily.hill@example.com','2223334444'),(29,'Logan','Kelly','logan.kelly@example.com','9998887776'),(30,'Abigail','Wright','abigail.wright@example.com','5556667777'),(31,'William','Johnson','william.johnson@example.com','1234567890'),(32,'Emma','Smith','emma.smith@example.com','9876543210'),(33,'James','Brown','james.brown@example.com','5551112222'),(34,'Olivia','Taylor','olivia.taylor@example.com','9998887776'),(35,'Liam','Miller','liam.miller@example.com','2223334444'),(36,'Ava','Jones','ava.jones@example.com','7778889999'),(37,'Noah','Davis','noah.davis@example.com','4445556666'),(38,'Isabella','Wilson','isabella.wilson@example.com','6667778888'),(39,'Sophia','Moore','sophia.moore@example.com','1112223333'),(40,'Jackson','Anderson','jackson.anderson@example.com','8889990000'),(41,'Aiden','Clark','aiden.clark@example.com','2223334444'),(42,'Mia','Harris','mia.harris@example.com','5556667777'),(43,'Lucas','Young','lucas.young@example.com','9990001111'),(44,'Harper','Walker','harper.walker@example.com','7776665555'),(45,'Benjamin','Lee','benjamin.lee@example.com','4443332222'),(46,'Evelyn','Martin','evelyn.martin@example.com','8887776666'),(47,'Jacob','Thompson','jacob.thompson@example.com','1112223333'),(48,'Elizabeth','Hall','elizabeth.hall@example.com','6665554444'),(49,'Michael','Adams','michael.adams@example.com','5554443333'),(50,'Emily','Roberts','emily.roberts@example.com','3332221111'),(51,'Daniel','Williams','daniel.williams@example.com','9998887776'),(52,'Avery','Brown','avery.brown@example.com','5556667777'),(53,'Sofia','Jones','sofia.jones@example.com','2223334444'),(54,'Logan','Thomas','logan.thomas@example.com','7778889999'),(55,'Lily','Davis','lily.davis@example.com','1112223333'),(56,'Henry','Smith','henry.smith@example.com','4445556666'),(57,'Grace','Wilson','grace.wilson@example.com','8889990000'),(58,'Jack','Miller','jack.miller@example.com','5556667777'),(59,'Nora','Anderson','nora.anderson@example.com','9990001111'),(60,'David','Taylor','david.taylor@example.com','3332221111'),(61,'Charlotte','Brown','charlotte.brown@example.com','6665554444'),(62,'Ethan','Lee','ethan.lee@example.com','5554443333'),(63,'Scarlett','Martin','scarlett.martin@example.com','3332221111'),(64,'Luke','Thompson','luke.thompson@example.com','9998887776'),(65,'Zoe','Hall','zoe.hall@example.com','5556667777'),(66,'Carter','Adams','carter.adams@example.com','2223334444'),(67,'Madison','Roberts','madison.roberts@example.com','7778889999'),(68,'Sebastian','Williams','sebastian.williams@example.com','1112223333'),(69,'Aubrey','Brown','aubrey.brown@example.com','6665554444'),(70,'Penelope','Thomas','penelope.thomas@example.com','5554443333'),(71,'Leo','Davis','leo.davis@example.com','3332221111'),(72,'Hannah','Smith','hannah.smith@example.com','9998887776'),(73,'Grayson','Wilson','grayson.wilson@example.com','5556667777'),(74,'Chloe','Miller','chloe.miller@example.com','2223334444'),(75,'Wyatt','Anderson','wyatt.anderson@example.com','7778889999'),(76,'Eleanor','Clark','eleanor.clark@example.com','1112223333'),(77,'Nathan','Harris','nathan.harris@example.com','6665554444'),(78,'Stella','Young','stella.young@example.com','5554443333'),(79,'Andrew','Walker','andrew.walker@example.com','3332221111'),(80,'Violet','Lee','violet.lee@example.com','9998887776'),(81,'Mila','Martin','mila.martin@example.com','5556667777'),(82,'Gabriel','Thompson','gabriel.thompson@example.com','2223334444'),(83,'Aria','Hall','aria.hall@example.com','7778889999'),(84,'Christopher','Adams','christopher.adams@example.com','1112223333'),(85,'Layla','Roberts','layla.roberts@example.com','6665554444'),(86,'Owen','Williams','owen.williams@example.com','5554443333'),(87,'Hazel','Brown','hazel.brown@example.com','3332221111'),(88,'Isaac','Thomas','isaac.thomas@example.com','9998887776'),(89,'Aurora','Davis','aurora.davis@example.com','5556667777'),(90,'Samuel','Smith','samuel.smith@example.com','2223334444'),(91,'Nova','Wilson','nova.wilson@example.com','7778889999'),(92,'Paisley','Miller','paisley.miller@example.com','1112223333'),(93,'Elijah','Anderson','elijah.anderson@example.com','6665554444'),(94,'Scarlet','Clark','scarlet.clark@example.com','5554443333'),(95,'Lincoln','Harris','lincoln.harris@example.com','3332221111'),(96,'Lily','Young','lily.young@example.com','9998887776'),(97,'Zachary','Walker','zachary.walker@example.com','5556667777'),(98,'Aaliyah','Lee','aaliyah.lee@example.com','2223334444'),(99,'Brooklyn','Martin','brooklyn.martin@example.com','7778889999'),(100,'Henry','Thompson','henry.thompson@example.com','1112223333'),(101,'Liam','Roberts','liam.roberts@example.com','6665554444'),(102,'Emma','Williams','emma.williams@example.com','5554443333'),(103,'Noah','Brown','noah.brown@example.com','3332221111'),(104,'Olivia','Thomas','olivia.thomas@example.com','9998887776'),(105,'Ava','Davis','ava.davis@example.com','5556667777'),(106,'William','Smith','william.smith@example.com','2223334444'),(107,'Sophia','Wilson','sophia.wilson@example.com','7778889999'),(108,'James','Miller','james.miller@example.com','1112223333'),(109,'Isabella','Anderson','isabella.anderson@example.com','6665554444'),(110,'Benjamin','Clark','benjamin.clark@example.com','5554443333'),(111,'Mia','Harris','mia.harris@example.com','3332221111'),(112,'Lucas','Young','lucas.young@example.com','9998887776'),(113,'Evelyn','Walker','evelyn.walker@example.com','5556667777'),(114,'Alexander','Lee','alexander.lee@example.com','2223334444'),(115,'Harper','Martin','harper.martin@example.com','7778889999'),(116,'Charlotte','Taylor','charlotte.taylor@example.com','1112223333'),(117,'Henry','Anderson','henry.anderson@example.com','6665554444'),(118,'Amelia','Moore','amelia.moore@example.com','5554443333'),(119,'Daniel','Jackson','daniel.jackson@example.com','3332221111'),(120,'Avery','Hill','avery.hill@example.com','9998887776'),(121,'Logan','Wright','logan.wright@example.com','5556667777'),(122,'Abigail','Green','abigail.green@example.com','2223334444'),(123,'Sebastian','Evans','sebastian.evans@example.com','7778889999'),(124,'Emily','Morris','emily.morris@example.com','1112223333'),(125,'Michael','Allen','michael.allen@example.com','6665554444'),(126,'Scarlett','Baker','scarlett.baker@example.com','5554443333'),(127,'David','Parker','david.parker@example.com','3332221111'),(128,'Sofia','Campbell','sofia.campbell@example.com','9998887776'),(129,'Joseph','Mitchell','joseph.mitchell@example.com','5556667777'),(130,'Lily','Robinson','lily.robinson@example.com','2223334444'),(131,'Christopher','Turner','christopher.turner@example.com','7778889999'),(132,'Grace','Carter','grace.carter@example.com','1112223333'),(133,'Andrew','Phillips','andrew.phillips@example.com','6665554444'),(134,'Zoe','Rogers','zoe.rogers@example.com','5554443333'),(135,'Daniel','Hall','daniel.hall@example.com','3332221111'),(136,'Chloe','Gonzalez','chloe.gonzalez@example.com','9998887776'),(137,'Matthew','Nelson','matthew.nelson@example.com','5556667777'),(138,'Victoria','Hill','victoria.hill@example.com','2223334444'),(139,'Joseph','Flores','joseph.flores@example.com','7778889999'),(140,'Aubrey','Rogers','aubrey.rogers@example.com','1112223333'),(141,'Ethan','Smith','ethan.smith@example.com','6665554444'),(142,'Hannah','Adams','hannah.adams@example.com','5554443333'),(143,'Samuel','Mitchell','samuel.mitchell@example.com','3332221111'),(144,'Grace','Stewart','grace.stewart@example.com','9998887776'),(145,'Christopher','Robinson','christopher.robinson@example.com','5556667777'),(146,'Bella','Gray','bella.gray@example.com','2223334444'),(147,'William','Morgan','william.morgan@example.com','7778889999'),(148,'Addison','Lee','addison.lee@example.com','1112223333'),(149,'Mason','Taylor','mason.taylor@example.com','6665554444'),(150,'Nora','Wilson','nora.wilson@example.com','5554443333'),(151,'Elijah','Hall','elijah.hall@example.com','3332221111'),(152,'Aria','Campbell','aria.campbell@example.com','9998887776'),(153,'Alexander','Wright','alexander.wright@example.com','5556667777'),(154,'Layla','Hill','layla.hill@example.com','2223334444'),(155,'Carter','Garcia','carter.garcia@example.com','7778889999');
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `route_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,'Route 1','Scenic drive along the coast'),(2,'Route 2','Mountainous terrain with breathtaking views'),(3,'Route 3','City tour through historical landmarks'),(4,'Route 4','Rural countryside with charming villages'),(5,'Route 5','Off-road adventure for thrill-seekers'),(6,'Route 6',NULL),(7,'Route 7',NULL),(8,'Route 8',NULL),(9,'Route 9',NULL),(10,'Route 10',NULL),(11,'Route 11',NULL),(12,'Route 12',NULL),(13,'Route 13',NULL),(14,'Route 14',NULL),(15,'Route 15',NULL),(16,'Route 16',NULL),(17,'Route 17',NULL),(18,'Route 18',NULL),(19,'Route 19',NULL),(20,'Route 20','TCDD'),(21,'Route 21',NULL),(22,'Route 22',NULL),(23,'Route 23',NULL),(24,'Route 24',NULL),(25,'Route 25',NULL),(26,'Route 26',NULL),(27,'Route 27',NULL),(28,'Route 28',NULL),(29,'Route 29',NULL),(30,'Route 30',NULL),(31,'Route 31',NULL),(32,'Route 32',NULL),(33,'Route 33',NULL),(34,'Route 34',NULL),(35,'Route 35',NULL),(36,'Route 36',NULL),(37,'Route 37',NULL),(38,'Route 38',NULL),(39,'Route 39',NULL),(40,'Route 40',NULL),(41,'Route 41',NULL),(42,'Route 42',NULL),(43,'Route 43',NULL),(44,'Route 44',NULL),(45,'Route 45',NULL),(46,'Route 46',NULL),(47,'Route 47',NULL),(48,'Route 48',NULL),(49,'Route 49',NULL),(50,'Route 50',NULL),(51,'Route 51',NULL),(52,'Route 52',NULL),(53,'Route 53',NULL),(54,'Route 54',NULL),(55,'Route 55',NULL),(56,'Route 56',NULL),(57,'Route 57',NULL),(58,'Route 58',NULL),(59,'Route 59',NULL),(60,'Route 60',NULL),(61,'Route 61',NULL),(62,'Route 62',NULL),(63,'Route 63',NULL),(64,'Route 64',NULL),(65,'Route 65',NULL),(66,'Route 66',NULL),(67,'Route 67',NULL),(68,'Route 68',NULL),(69,'Route 69',NULL),(70,'Route 70',NULL),(71,'Route 71',NULL),(72,'Route 72',NULL),(73,'Route 73',NULL),(74,'Route 74',NULL),(75,'Route 75',NULL),(76,'Route 76',NULL),(77,'Route 77',NULL),(78,'Route 78',NULL),(79,'Route 79',NULL),(80,'Route 80',NULL),(81,'Route 81',NULL),(82,'Route 82',NULL),(83,'Route 83',NULL),(84,'Route 84',NULL),(85,'Route 85',NULL),(86,'Route 86',NULL),(87,'Route 87',NULL),(88,'Route 88',NULL),(89,'Route 89',NULL),(90,'Route 90',NULL),(91,'Route 91',NULL),(92,'Route 92',NULL),(93,'Route 93',NULL),(94,'Route 94',NULL),(95,'Route 95',NULL),(96,'Route 96',NULL),(97,'Route 97',NULL),(98,'Route 98',NULL),(99,'Route 99',NULL),(100,'Route 100',NULL),(101,'Route 101',NULL),(102,'Route 102',NULL),(103,'Route 103',NULL),(104,'Route 104',NULL),(105,'Route 105',NULL),(106,'Route 106',NULL),(107,'Route 107',NULL),(108,'Route 108',NULL),(109,'Route 109',NULL),(110,'Route 110',NULL);
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routefaretype`
--

DROP TABLE IF EXISTS `routefaretype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routefaretype` (
  `route_id` int NOT NULL,
  `fare_type_id` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`route_id`,`fare_type_id`),
  KEY `fk_fare_type_id_RouteFareType` (`fare_type_id`),
  CONSTRAINT `fk_fare_type_id_RouteFareType` FOREIGN KEY (`fare_type_id`) REFERENCES `faretype` (`fare_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_route_id_RouteFareType` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routefaretype`
--

LOCK TABLES `routefaretype` WRITE;
/*!40000 ALTER TABLE `routefaretype` DISABLE KEYS */;
INSERT INTO `routefaretype` VALUES (1,1,10.00),(1,2,15.00),(2,1,12.50),(2,3,20.00),(3,2,18.00),(3,4,25.00),(4,1,11.00),(4,3,18.50),(5,2,16.00),(5,4,22.50),(6,1,13.50),(6,2,19.00),(7,2,17.50),(7,3,23.50),(8,4,24.00),(8,5,30.00),(9,3,21.00),(9,4,28.50),(10,5,26.50),(10,6,35.00),(11,1,14.50),(11,3,22.00),(12,2,18.50),(12,4,26.00),(13,3,21.50),(13,5,29.50),(14,4,25.50),(14,6,34.50),(15,1,15.50),(15,2,20.50),(16,2,19.50),(16,3,24.50),(17,4,26.50),(17,5,32.50),(18,3,23.00),(18,4,29.00),(19,5,28.00),(19,6,36.50),(20,1,16.50),(20,3,25.00),(21,2,21.50),(21,4,27.50),(22,3,24.00),(22,5,31.00),(23,4,27.00),(23,6,35.50),(24,1,17.50),(24,2,22.50),(25,2,23.50),(25,3,25.50),(26,4,28.50),(26,5,33.50),(27,1,14.50),(27,2,19.50),(28,2,20.50),(28,3,25.50),(29,4,28.50),(29,5,33.50),(30,3,23.50),(30,4,29.50),(31,5,30.50),(31,6,37.50),(32,1,15.50),(32,3,24.50),(33,2,21.50),(33,4,28.50),(34,3,24.50),(34,5,32.50),(35,4,28.50),(35,6,36.50),(36,1,16.50),(36,2,22.50),(37,2,22.50),(37,3,26.50),(38,4,29.50),(38,5,34.50),(39,3,25.50),(39,4,30.50),(40,5,31.50),(40,6,38.50),(41,1,17.50),(41,3,26.50),(42,2,23.50),(42,4,29.50),(43,3,25.50),(43,5,33.50),(44,4,29.50),(44,6,37.50),(45,1,18.50),(45,2,24.50),(46,2,24.50),(46,3,27.50),(47,4,30.50),(47,5,35.50),(48,1,19.50),(48,2,25.50),(49,2,25.50),(49,3,28.50),(50,4,31.50),(50,5,36.50),(51,3,27.50),(51,4,33.50),(52,5,34.50),(52,6,41.50),(53,1,20.50),(53,3,29.50),(54,2,26.50),(54,4,32.50),(55,3,28.50),(55,5,36.50),(56,4,32.50),(56,6,40.50),(57,1,21.50),(57,2,27.50),(58,2,27.50),(58,3,30.50),(59,4,33.50),(59,5,38.50),(60,3,29.50),(60,4,34.50),(61,5,35.50),(61,6,42.50),(62,1,22.50),(62,3,30.50),(63,2,28.50),(63,4,34.50),(64,3,29.50),(64,5,37.50),(65,4,33.50),(65,6,41.50),(66,1,23.50),(66,2,29.50),(67,2,29.50),(67,3,32.50),(68,4,35.50),(68,5,40.50),(69,1,24.50),(69,3,31.50),(70,2,30.50),(70,4,36.50),(71,3,31.50),(71,5,39.50),(72,4,35.50),(72,6,43.50),(73,1,25.50),(73,2,31.50),(74,2,31.50),(74,3,34.50),(75,4,37.50),(75,5,42.50),(76,3,33.50),(76,4,38.50),(77,5,39.50),(77,6,46.50),(78,1,26.50),(78,3,34.50),(79,2,32.50),(79,4,38.50),(80,3,33.50),(80,5,41.50),(81,4,36.50),(81,6,44.50),(82,1,27.50),(82,2,33.50),(83,2,33.50),(83,3,36.50),(84,4,39.50),(84,5,44.50),(85,3,35.50),(85,4,40.50),(86,5,41.50),(86,6,48.50),(87,1,28.50),(87,3,36.50),(88,2,34.50),(88,4,40.50),(89,3,35.50),(89,5,43.50),(90,4,38.50),(90,6,46.50),(91,1,29.50),(92,3,37.50),(93,2,35.50),(94,4,41.50),(95,3,36.50),(96,5,44.50),(97,4,39.50),(98,6,47.50),(99,1,30.50),(100,2,36.50),(101,2,36.50),(110,3,39.50);
/*!40000 ALTER TABLE `routefaretype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routestop`
--

DROP TABLE IF EXISTS `routestop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `routestop` (
  `route_id` int NOT NULL,
  `stop_id` int NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`route_id`,`stop_id`),
  KEY `fk_stop_id` (`stop_id`),
  CONSTRAINT `fk_route_id` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_stop_id` FOREIGN KEY (`stop_id`) REFERENCES `stop` (`stop_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routestop`
--

LOCK TABLES `routestop` WRITE;
/*!40000 ALTER TABLE `routestop` DISABLE KEYS */;
INSERT INTO `routestop` VALUES (1,1,'Route 1, Stop 1','2023-07-21'),(1,2,'Route 1, Stop 2','2023-07-22'),(1,3,'Route 1, Stop 3','2023-07-23'),(1,4,'Route 1, Stop 4','2023-07-24'),(1,5,'Route 1, Stop 5','2023-07-25'),(2,6,'Route 2, Stop 6','2023-07-21'),(2,7,'Route 2, Stop 7','2023-07-22'),(2,8,'Route 2, Stop 8','2023-07-23'),(2,9,'Route 2, Stop 9','2023-07-24'),(2,10,'Route 2, Stop 10','2023-07-25'),(3,11,'Route 3, Stop 11','2023-07-21'),(3,12,'Route 3, Stop 12','2023-07-22'),(3,13,'Route 3, Stop 13','2023-07-23'),(3,14,'Route 3, Stop 14','2023-07-24'),(3,15,'Route 3, Stop 15','2023-07-25'),(4,16,'Route 4, Stop 16','2023-07-21'),(4,17,'Route 4, Stop 17','2023-07-22'),(4,18,'Route 4, Stop 18','2023-07-23'),(4,19,'Route 4, Stop 19','2023-07-24'),(4,20,'Route 4, Stop 20','2023-07-25'),(5,21,'Route 5, Stop 21','2023-07-21'),(5,22,'Route 5, Stop 22','2023-07-22'),(5,23,'Route 5, Stop 23','2023-07-23'),(5,24,'Route 5, Stop 24','2023-07-24'),(5,25,'Route 5, Stop 25','2023-07-25'),(6,26,'Route 6, Stop 26','2023-07-21'),(6,27,'Route 6, Stop 27','2023-07-22'),(6,28,'Route 6, Stop 28','2023-07-23'),(6,29,'Route 6, Stop 29','2023-07-24'),(6,30,'Route 6, Stop 30','2023-07-25'),(7,31,'Route 7, Stop 31','2023-07-21'),(7,32,'Route 7, Stop 32','2023-07-22'),(7,33,'Route 7, Stop 33','2023-07-23'),(7,34,'Route 7, Stop 34','2023-07-24'),(7,35,'Route 7, Stop 35','2023-07-25'),(8,36,'Route 8, Stop 36','2023-07-21'),(8,37,'Route 8, Stop 37','2023-07-22'),(8,38,'Route 8, Stop 38','2023-07-23'),(8,39,'Route 8, Stop 39','2023-07-24'),(8,40,'Route 8, Stop 40','2023-07-25'),(9,41,'Route 9, Stop 41','2023-07-21'),(9,42,'Route 9, Stop 42','2023-07-22'),(9,43,'Route 9, Stop 43','2023-07-23'),(9,44,'Route 9, Stop 44','2023-07-24'),(9,45,'Route 9, Stop 45','2023-07-25'),(10,46,'Route 10, Stop 46','2023-07-21'),(10,47,'Route 10, Stop 47','2023-07-22'),(10,48,'Route 10, Stop 48','2023-07-23'),(10,49,'Route 10, Stop 49','2023-07-24'),(10,50,'Route 10, Stop 50','2023-07-25'),(11,1,'First stop of Route 11','2023-01-01'),(11,2,'Second stop of Route 11','2023-01-02'),(11,3,'Third stop of Route 11','2023-01-03'),(12,1,'First stop of Route 12','2023-01-01'),(12,2,'Second stop of Route 12','2023-01-02'),(12,3,'Third stop of Route 12','2023-01-03'),(13,1,'First stop of Route 13','2023-01-01'),(13,2,'Second stop of Route 13','2023-01-02'),(13,3,'Third stop of Route 13','2023-01-03'),(14,1,'First stop of Route 14','2023-01-01'),(14,2,'Second stop of Route 14','2023-01-02'),(14,3,'Third stop of Route 14','2023-01-03'),(15,1,'First stop of Route 15','2023-01-01'),(15,2,'Second stop of Route 15','2023-01-02'),(15,3,'Third stop of Route 15','2023-01-03'),(16,1,'First stop of Route 16','2023-01-01'),(16,2,'Second stop of Route 16','2023-01-02'),(16,3,'Third stop of Route 16','2023-01-03'),(17,1,'First stop of Route 17','2023-01-01'),(17,2,'Second stop of Route 17','2023-01-02'),(17,3,'Third stop of Route 17','2023-01-03'),(18,1,'First stop of Route 18','2023-01-01'),(18,2,'Second stop of Route 18','2023-01-02'),(18,3,'Third stop of Route 18','2023-01-03'),(19,1,'First stop of Route 19','2023-01-01'),(19,2,'Second stop of Route 19','2023-01-02'),(19,3,'Third stop of Route 19','2023-01-03'),(20,1,'First stop of Route 20','2023-01-01'),(20,2,'Second stop of Route 20','2023-01-02'),(20,3,'Third stop of Route 20','2023-01-03'),(21,1,'First stop on route 21','2023-05-21'),(22,2,'Second stop on route 22','2023-05-22'),(23,3,'Third stop on route 23','2023-05-23'),(24,4,'Fourth stop on route 24','2023-05-24'),(25,5,'Fifth stop on route 25','2023-05-25'),(26,6,'Sixth stop on route 26','2023-05-26'),(27,7,'Seventh stop on route 27','2023-05-27'),(28,8,'Eighth stop on route 28','2023-05-28'),(29,9,'Ninth stop on route 29','2023-05-29'),(30,10,'Tenth stop on route 30','2023-05-30'),(31,11,'Eleventh stop on route 31','2023-05-31'),(32,12,'Twelfth stop on route 32','2023-06-01'),(33,13,'Thirteenth stop on route 33','2023-06-02'),(34,14,'Fourteenth stop on route 34','2023-06-03'),(35,15,'Fifteenth stop on route 35','2023-06-04'),(36,16,'Sixteenth stop on route 36','2023-06-05'),(37,17,'Seventeenth stop on route 37','2023-06-06'),(38,18,'Eighteenth stop on route 38','2023-06-07'),(39,19,'Nineteenth stop on route 39','2023-06-08'),(40,20,'Twentieth stop on route 40','2023-06-09'),(41,21,'Twenty-first stop on route 41','2023-06-10'),(42,22,'Twenty-second stop on route 42','2023-06-11'),(43,23,'Twenty-third stop on route 43','2023-06-12'),(44,24,'Twenty-fourth stop on route 44','2023-06-13'),(45,25,'Twenty-fifth stop on route 45','2023-06-14'),(46,26,'Twenty-sixth stop on route 46','2023-06-15'),(47,27,'Twenty-seventh stop on route 47','2023-06-16'),(48,28,'Twenty-eighth stop on route 48','2023-06-17'),(49,29,'Twenty-ninth stop on route 49','2023-06-18'),(50,30,'Thirtieth stop on route 50','2023-06-19'),(51,31,'Thirty-first stop on route 51','2023-06-20'),(52,32,'Thirty-second stop on route 52','2023-06-21'),(53,33,'Thirty-third stop on route 53','2023-06-22'),(54,34,'Thirty-fourth stop on route 54','2023-06-23'),(55,35,'Thirty-fifth stop on route 55','2023-06-24'),(56,36,'Thirty-sixth stop on route 56','2023-06-25'),(57,37,'Thirty-seventh stop on route 57','2023-06-26'),(58,38,'Thirty-eighth stop on route 58','2023-06-27'),(59,39,'Thirty-ninth stop on route 59','2023-06-28'),(60,40,'Route 60, Stop 40','2023-07-11'),(60,41,'Route 60, Stop 41','2023-07-12'),(60,42,'Route 60, Stop 42','2023-07-13'),(60,43,'Route 60, Stop 43','2023-07-14'),(60,44,'Route 60, Stop 44','2023-07-15'),(60,45,'Route 60, Stop 45','2023-07-16'),(60,46,'Route 60, Stop 46','2023-07-17'),(60,47,'Route 60, Stop 47','2023-07-18'),(60,48,'Route 60, Stop 48','2023-07-19'),(60,49,'Route 60, Stop 49','2023-07-20'),(61,40,'Route 61, Stop 40','2023-07-11'),(61,41,'Route 61, Stop 41','2023-07-12'),(61,42,'Route 61, Stop 42','2023-07-13'),(61,43,'Route 61, Stop 43','2023-07-14'),(61,44,'Route 61, Stop 44','2023-07-15'),(61,45,'Route 61, Stop 45','2023-07-16'),(61,46,'Route 61, Stop 46','2023-07-17'),(61,47,'Route 61, Stop 47','2023-07-18'),(61,48,'Route 61, Stop 48','2023-07-19'),(61,49,'Route 61, Stop 49','2023-07-20'),(62,40,'Route 62, Stop 40','2023-07-11'),(62,41,'Route 62, Stop 41','2023-07-12'),(62,42,'Route 62, Stop 42','2023-07-13'),(62,43,'Route 62, Stop 43','2023-07-14'),(62,44,'Route 62, Stop 44','2023-07-15'),(62,45,'Route 62, Stop 45','2023-07-16'),(62,46,'Route 62, Stop 46','2023-07-17'),(62,47,'Route 62, Stop 47','2023-07-18'),(62,48,'Route 62, Stop 48','2023-07-19'),(62,49,'Route 62, Stop 49','2023-07-20'),(63,40,'Route 63, Stop 40','2023-07-11'),(63,41,'Route 63, Stop 41','2023-07-12'),(63,42,'Route 63, Stop 42','2023-07-13'),(63,43,'Route 63, Stop 43','2023-07-14'),(63,44,'Route 63, Stop 44','2023-07-15'),(63,45,'Route 63, Stop 45','2023-07-16'),(63,46,'Route 63, Stop 46','2023-07-17'),(63,47,'Route 63, Stop 47','2023-07-18'),(63,48,'Route 63, Stop 48','2023-07-19'),(63,49,'Route 63, Stop 49','2023-07-20'),(64,40,'Route 64, Stop 40','2023-07-11'),(64,41,'Route 64, Stop 41','2023-07-12'),(64,42,'Route 64, Stop 42','2023-07-13'),(64,43,'Route 64, Stop 43','2023-07-14'),(64,44,'Route 64, Stop 44','2023-07-15'),(64,45,'Route 64, Stop 45','2023-07-16'),(64,46,'Route 64, Stop 46','2023-07-17'),(64,47,'Route 64, Stop 47','2023-07-18'),(64,48,'Route 64, Stop 48','2023-07-19'),(64,49,'Route 64, Stop 49','2023-07-20'),(65,40,'Route 65, Stop 40','2023-07-11'),(65,41,'Route 65, Stop 41','2023-07-12'),(65,42,'Route 65, Stop 42','2023-07-13'),(65,43,'Route 65, Stop 43','2023-07-14'),(65,44,'Route 65, Stop 44','2023-07-15'),(65,45,'Route 65, Stop 45','2023-07-16'),(65,46,'Route 65, Stop 46','2023-07-17'),(65,47,'Route 65, Stop 47','2023-07-18'),(65,48,'Route 65, Stop 48','2023-07-19'),(65,49,'Route 65, Stop 49','2023-07-20'),(66,40,'Route 66, Stop 40','2023-07-11'),(66,41,'Route 66, Stop 41','2023-07-12'),(66,42,'Route 66, Stop 42','2023-07-13'),(66,43,'Route 66, Stop 43','2023-07-14'),(66,44,'Route 66, Stop 44','2023-07-15'),(66,45,'Route 66, Stop 45','2023-07-16'),(66,46,'Route 66, Stop 46','2023-07-17'),(66,47,'Route 66, Stop 47','2023-07-18'),(66,48,'Route 66, Stop 48','2023-07-19'),(66,49,'Route 66, Stop 49','2023-07-20'),(67,47,'Route 67, Stop 47','2023-05-28'),(68,48,'Route 68, Stop 48','2023-05-29'),(69,49,'Route 69, Stop 49','2023-05-30'),(70,50,'Route 70, Stop 50','2023-06-01'),(71,51,'Route 71, Stop 51','2023-06-02'),(72,52,'Route 72, Stop 52','2023-06-03'),(73,53,'Route 73, Stop 53','2023-06-04'),(74,54,'Route 74, Stop 54','2023-06-05'),(75,55,'Route 75, Stop 55','2023-06-06'),(76,56,'Route 76, Stop 56','2023-06-07'),(77,57,'Route 77, Stop 57','2023-06-08'),(78,58,'Route 78, Stop 58','2023-06-09'),(79,59,'Route 79, Stop 59','2023-06-10'),(80,60,'Route 80, Stop 60','2023-06-11'),(81,61,'Route 81, Stop 61','2023-06-12'),(82,62,'Route 82, Stop 62','2023-06-13'),(83,63,'Route 83, Stop 63','2023-06-14'),(84,64,'Route 84, Stop 64','2023-06-15'),(85,65,'Route 85, Stop 65','2023-06-16'),(86,66,'Route 86, Stop 66','2023-06-17'),(87,67,'Route 87, Stop 67','2023-06-18'),(88,68,'Route 88, Stop 68','2023-06-19'),(89,69,'Route 89, Stop 69','2023-06-20'),(90,70,'Route 90, Stop 70','2023-06-21'),(91,71,'Route 91, Stop 71','2023-06-22'),(92,72,'Route 92, Stop 72','2023-06-23'),(93,73,'Route 93, Stop 73','2023-06-24'),(94,74,'Route 94, Stop 74','2023-06-25'),(95,75,'Route 95, Stop 75','2023-06-26'),(96,76,'Route 96, Stop 76','2023-06-27'),(97,77,'Route 97, Stop 77','2023-06-28'),(98,78,'Route 98, Stop 78','2023-06-29'),(99,79,'Route 99, Stop 79','2023-06-30'),(100,80,'Route 100, Stop 80','2023-07-01'),(101,81,'Route 101, Stop 81','2023-07-02'),(102,82,'Route 102, Stop 82','2023-07-03'),(103,83,'Route 103, Stop 83','2023-07-04'),(104,84,'Route 104, Stop 84','2023-07-05'),(105,85,'Route 105, Stop 85','2023-07-06'),(106,86,'Route 106, Stop 86','2023-07-07'),(107,87,'Route 107, Stop 87','2023-07-08'),(108,88,'Route 108, Stop 88','2023-07-09'),(109,89,'Route 109, Stop 89','2023-07-10');
/*!40000 ALTER TABLE `routestop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `schedule_id` int NOT NULL,
  `route_id` int NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `fk_schedule_id_Schedule` (`route_id`),
  CONSTRAINT `fk_schedule_id_Schedule` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES (1,1,'08:00:00','10:00:00'),(2,2,'09:30:00','11:30:00'),(3,3,'12:00:00','14:00:00'),(4,4,'14:30:00','16:30:00'),(5,5,'16:00:00','18:00:00'),(6,6,'18:30:00','20:30:00'),(7,7,'20:00:00','22:00:00'),(8,8,'07:30:00','09:30:00'),(9,9,'10:30:00','12:30:00'),(10,10,'13:30:00','15:30:00'),(11,11,'08:30:00','10:30:00'),(12,12,'09:00:00','11:00:00'),(13,13,'10:30:00','12:30:00'),(14,14,'11:00:00','13:00:00'),(15,15,'12:30:00','14:30:00'),(16,16,'13:00:00','15:00:00'),(17,17,'14:30:00','16:30:00'),(18,18,'15:00:00','17:00:00'),(19,19,'16:30:00','18:30:00'),(20,20,'17:00:00','19:00:00'),(21,21,'18:30:00','20:30:00'),(22,22,'19:00:00','21:00:00'),(23,23,'20:30:00','22:30:00'),(24,24,'21:00:00','23:00:00'),(25,25,'07:30:00','09:30:00'),(26,26,'08:00:00','10:00:00'),(27,27,'09:30:00','11:30:00'),(28,28,'10:00:00','12:00:00'),(29,29,'11:30:00','13:30:00'),(30,30,'12:00:00','14:00:00'),(31,31,'08:30:00','10:30:00'),(32,32,'09:00:00','11:00:00'),(33,33,'10:30:00','12:30:00'),(34,34,'11:00:00','13:00:00'),(35,35,'12:30:00','14:30:00'),(36,36,'13:00:00','15:00:00'),(37,37,'14:30:00','16:30:00'),(38,38,'15:00:00','17:00:00'),(39,39,'16:30:00','18:30:00'),(40,40,'17:00:00','19:00:00'),(41,41,'18:30:00','20:30:00'),(42,42,'19:00:00','21:00:00'),(43,43,'20:30:00','22:30:00'),(44,44,'21:00:00','23:00:00'),(45,45,'07:30:00','09:30:00'),(46,46,'08:00:00','10:00:00'),(47,47,'09:30:00','11:30:00'),(48,48,'10:00:00','12:00:00'),(49,49,'11:30:00','13:30:00'),(50,50,'12:00:00','14:00:00'),(51,51,'13:30:00','15:30:00'),(52,52,'14:00:00','16:00:00'),(53,53,'15:30:00','17:30:00'),(54,54,'16:00:00','18:00:00'),(55,55,'17:30:00','19:30:00'),(56,56,'18:00:00','20:00:00'),(57,57,'19:30:00','21:30:00'),(58,58,'20:00:00','22:00:00'),(59,59,'21:30:00','23:30:00'),(60,60,'22:00:00','00:00:00'),(61,61,'08:30:00','10:30:00'),(62,62,'09:00:00','11:00:00'),(63,63,'10:30:00','12:30:00'),(64,64,'11:00:00','13:00:00'),(65,65,'12:30:00','14:30:00'),(66,66,'13:00:00','15:00:00'),(67,67,'14:30:00','16:30:00'),(68,68,'15:00:00','17:00:00'),(69,69,'16:30:00','18:30:00'),(70,70,'17:00:00','19:00:00'),(71,71,'18:30:00','20:30:00'),(72,72,'19:00:00','21:00:00'),(73,73,'20:30:00','22:30:00'),(74,74,'21:00:00','23:00:00'),(75,75,'07:30:00','09:30:00'),(76,76,'08:00:00','10:00:00'),(77,77,'09:30:00','11:30:00'),(78,78,'10:00:00','12:00:00'),(79,79,'11:30:00','13:30:00'),(80,80,'12:00:00','14:00:00'),(81,81,'13:30:00','15:30:00'),(82,82,'14:00:00','16:00:00'),(83,83,'15:30:00','17:30:00'),(84,84,'16:00:00','18:00:00'),(85,85,'17:30:00','19:30:00'),(86,86,'18:00:00','20:00:00'),(87,87,'19:30:00','21:30:00'),(88,88,'20:00:00','22:00:00'),(89,89,'21:30:00','23:30:00'),(90,90,'22:00:00','00:00:00'),(91,91,'08:30:00','10:30:00'),(92,92,'09:00:00','11:00:00'),(93,93,'10:30:00','12:30:00'),(94,94,'11:00:00','13:00:00'),(95,95,'12:30:00','14:30:00'),(96,96,'13:00:00','15:00:00'),(97,97,'14:30:00','16:30:00'),(98,98,'15:00:00','17:00:00'),(99,99,'16:30:00','18:30:00'),(100,100,'17:00:00','19:00:00'),(101,101,'08:12:00','09:45:00'),(102,102,'09:24:00','11:15:00'),(103,103,'10:38:00','12:20:00'),(104,104,'11:52:00','13:35:00'),(105,105,'13:06:00','14:50:00'),(106,106,'14:20:00','16:05:00'),(107,107,'15:34:00','17:20:00'),(108,108,'16:48:00','18:35:00'),(109,109,'18:02:00','19:50:00'),(110,110,'19:16:00','21:05:00');
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stop`
--

DROP TABLE IF EXISTS `stop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stop` (
  `stop_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `latitude` decimal(11,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  PRIMARY KEY (`stop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stop`
--

LOCK TABLES `stop` WRITE;
/*!40000 ALTER TABLE `stop` DISABLE KEYS */;
INSERT INTO `stop` VALUES (1,'Stop 1',37.12345678,-122.12345678),(2,'Stop 2',38.12345678,-123.12345678),(3,'Stop 3',39.12345678,-124.12345678),(4,'Stop 4',40.12345678,-125.12345678),(5,'Stop 5',41.12345678,-126.12345678),(6,'Stop 6',42.12345678,-127.12345678),(7,'Stop 7',43.12345678,-128.12345678),(8,'Stop 8',44.12345678,-129.12345678),(9,'Stop 9',45.12345678,-130.12345678),(10,'Stop 10',46.12345678,-131.12345678),(11,'Stop 11',47.12345678,-132.12345678),(12,'Stop 12',48.12345678,-133.12345678),(13,'Stop 13',49.12345678,-134.12345678),(14,'Stop 14',50.12345678,-135.12345678),(15,'Stop 15',51.12345678,-136.12345678),(16,'Stop 16',52.12345678,-137.12345678),(17,'Stop 17',53.12345678,-138.12345678),(18,'Stop 18',54.12345678,-139.12345678),(19,'Stop 19',55.12345678,-140.12345678),(20,'Stop 20',56.12345678,-141.12345678),(21,'Stop 21',57.12345678,-142.12345678),(22,'Stop 22',58.12345678,-143.12345678),(23,'Stop 23',59.12345678,-144.12345678),(24,'Stop 24',60.12345678,-145.12345678),(25,'Stop 25',61.12345678,-146.12345678),(26,'Stop 26',62.12345678,-147.12345678),(27,'Stop 27',63.12345678,-148.12345678),(28,'Stop 28',64.12345678,-149.12345678),(29,'Stop 29',65.12345678,-150.12345678),(30,'Stop 30',66.12345678,-151.12345678),(31,'Stop 31',67.12345678,-152.12345678),(32,'Stop 32',68.12345678,-153.12345678),(33,'Stop 33',69.12345678,-154.12345678),(34,'Stop 34',70.12345678,-155.12345678),(35,'Stop 35',71.12345678,-156.12345678),(36,'Stop 36',72.12345678,-157.12345678),(37,'Stop 37',73.12345678,-158.12345678),(38,'Stop 38',74.12345678,-159.12345678),(39,'Stop 39',75.12345678,-160.12345678),(40,'Stop 40',76.12345678,-161.12345678),(41,'Stop 41',77.12345678,-162.12345678),(42,'Stop 42',78.12345678,-163.12345678),(43,'Stop 43',79.12345678,-164.12345678),(44,'Stop 44',80.12345678,-165.12345678),(45,'Stop 45',81.12345678,-166.12345678),(46,'Stop 46',82.12345678,-167.12345678),(47,'Stop 47',83.12345678,-168.12345678),(48,'Stop 48',84.12345678,-169.12345678),(49,'Stop 49',85.12345678,-170.12345678),(50,'Stop 50',86.12345678,-171.12345678),(51,'Stop 51',87.12345678,-172.12345678),(52,'Stop 52',88.12345678,-173.12345678),(53,'Stop 53',89.12345678,-174.12345678),(54,'Stop 54',90.12345678,-175.12345678),(55,'Stop 55',91.12345678,-176.12345678),(56,'Stop 56',92.12345678,-177.12345678),(57,'Stop 57',93.12345678,-178.12345678),(58,'Stop 58',94.12345678,-179.12345678),(59,'Stop 59',95.12345678,-180.12345678),(60,'Stop 60',96.12345678,-181.12345678),(61,'Stop 61',97.12345678,-182.12345678),(62,'Stop 62',98.12345678,-183.12345678),(63,'Stop 63',99.12345678,-184.12345678),(64,'Stop 64',100.12345678,-185.12345678),(65,'Stop 65',101.12345678,-186.12345678),(66,'Stop 66',102.12345678,-187.12345678),(67,'Stop 67',103.12345678,-188.12345678),(68,'Stop 68',104.12345678,-189.12345678),(69,'Stop 69',105.12345678,-190.12345678),(70,'Stop 70',106.12345678,-191.12345678),(71,'Stop 71',107.12345678,-192.12345678),(72,'Stop 72',108.12345678,-193.12345678),(73,'Stop 73',109.12345678,-194.12345678),(74,'Stop 74',110.12345678,-195.12345678),(75,'Stop 75',111.12345678,-196.12345678),(76,'Stop 76',112.12345678,-197.12345678),(77,'Stop 77',113.12345678,-198.12345678),(78,'Stop 78',114.12345678,-199.12345678),(79,'Stop 79',115.12345678,-200.12345678),(80,'Stop 80',116.12345678,-201.12345678),(81,'Stop 81',117.12345678,-202.12345678),(82,'Stop 82',118.12345678,-203.12345678),(83,'Stop 83',119.12345678,-204.12345678),(84,'Stop 84',120.12345678,-205.12345678),(85,'Stop 85',121.12345678,-206.12345678),(86,'Stop 86',122.12345678,-207.12345678),(87,'Stop 87',123.12345678,-208.12345678),(88,'Stop 88',124.12345678,-209.12345678),(89,'Stop 89',125.12345678,-210.12345678),(90,'Stop 90',126.12345678,-211.12345678),(91,'Stop 91',127.12345678,-212.12345678),(92,'Stop 92',128.12345678,-213.12345678),(93,'Stop 93',129.12345678,-214.12345678),(94,'Stop 94',130.12345678,-215.12345678),(95,'Stop 95',131.12345678,-216.12345678),(96,'Stop 96',132.12345678,-217.12345678),(97,'Stop 97',133.12345678,-218.12345678),(98,'Stop 98',134.12345678,-219.12345678),(99,'Stop 99',135.12345678,-220.12345678),(100,'Stop 100',136.12345678,-221.12345678),(101,'Stop 101',137.12345678,-222.12345678),(102,'Stop 102',138.12345678,-223.12345678),(103,'Stop 103',139.12345678,-224.12345678),(104,'Stop 104',140.12345678,-225.12345678),(105,'Stop 105',141.12345678,-226.12345678),(106,'Stop 106',142.12345678,-227.12345678),(107,'Stop 107',143.12345678,-228.12345678),(108,'Stop 108',144.12345678,-229.12345678),(109,'Stop 109',145.12345678,-230.12345678),(110,'Stop 110',146.12345678,-231.12345678),(111,'Stop 111',147.12345678,-232.12345678),(112,'Stop 112',148.12345678,-233.12345678),(113,'Stop 113',149.12345678,-234.12345678),(114,'Stop 114',150.12345678,-235.12345678),(115,'Stop 115',151.12345678,-236.12345678),(116,'Stop 116',152.12345678,-237.12345678),(117,'Stop 117',153.12345678,-238.12345678),(118,'Stop 118',154.12345678,-239.12345678),(119,'Stop 119',155.12345678,-240.12345678),(120,'Stop 120',156.12345678,-241.12345678),(121,'Stop 121',157.12345678,-242.12345678),(122,'Stop 122',158.12345678,-243.12345678),(123,'Stop 123',159.12345678,-244.12345678),(124,'Stop 124',160.12345678,-245.12345678),(125,'Stop 125',161.12345678,-246.12345678),(126,'Stop 126',162.12345678,-247.12345678),(127,'Stop 127',163.12345678,-248.12345678),(128,'Stop 128',164.12345678,-249.12345678),(129,'Stop 129',165.12345678,-250.12345678),(130,'Stop 130',166.12345678,-251.12345678),(131,'Stop 131',167.12345678,-252.12345678),(132,'Stop 132',168.12345678,-253.12345678),(133,'Stop 133',169.12345678,-254.12345678),(134,'Stop 134',170.12345678,-255.12345678),(135,'Stop 135',171.12345678,-256.12345678),(136,'Stop 136',172.12345678,-257.12345678),(137,'Stop 137',173.12345678,-258.12345678),(138,'Stop 138',174.12345678,-259.12345678),(139,'Stop 139',175.12345678,-260.12345678),(140,'Stop 140',176.12345678,-261.12345678),(141,'Stop 141',177.12345678,-262.12345678),(142,'Stop 142',178.12345678,-263.12345678),(143,'Stop 143',179.12345678,-264.12345678),(144,'Stop 144',180.12345678,-265.12345678),(145,'Stop 145',181.12345678,-266.12345678),(146,'Stop 146',182.12345678,-267.12345678),(147,'Stop 147',183.12345678,-268.12345678),(148,'Stop 148',184.12345678,-269.12345678),(149,'Stop 149',185.12345678,-270.12345678),(150,'Stop 150',186.12345678,-271.12345678),(151,'Stop 151',187.12345678,-272.12345678),(152,'Stop 152',188.12345678,-273.12345678),(153,'Stop 153',189.12345678,-274.12345678),(154,'Stop 154',190.12345678,-275.12345678),(155,'Stop 155',191.12345678,-276.12345678),(156,'Stop 156',192.12345678,-277.12345678),(157,'Stop 157',193.12345678,-278.12345678),(158,'Stop 158',194.12345678,-279.12345678),(159,'Stop 159',195.12345678,-280.12345678),(160,'Stop 160',196.12345678,-281.12345678),(161,'Stop 161',197.12345678,-282.12345678),(162,'Stop 162',198.12345678,-283.12345678),(163,'Stop 163',199.12345678,-284.12345678),(164,'Stop 164',200.12345678,-285.12345678),(165,'Stop 165',201.12345678,-286.12345678),(166,'Stop 166',202.12345678,-287.12345678),(167,'Stop 167',203.12345678,-288.12345678),(168,'Stop 168',204.12345678,-289.12345678),(169,'Stop 169',205.12345678,-290.12345678),(170,'Stop 170',206.12345678,-291.12345678),(171,'Stop 171',207.12345678,-292.12345678),(172,'Stop 172',208.12345678,-293.12345678),(173,'Stop 173',209.12345678,-294.12345678),(174,'Stop 174',210.12345678,-295.12345678),(175,'Stop 175',211.12345678,-296.12345678),(176,'Stop 176',212.12345678,-297.12345678),(177,'Stop 177',213.12345678,-298.12345678),(178,'Stop 178',214.12345678,-299.12345678),(179,'Stop 179',215.12345678,-300.12345678),(180,'Stop 180',216.12345678,-301.12345678),(181,'Stop 181',217.12345678,-302.12345678),(182,'Stop 182',218.12345678,-303.12345678),(183,'Stop 183',219.12345678,-304.12345678),(184,'Stop 184',220.12345678,-305.12345678),(185,'Stop 185',221.12345678,-306.12345678),(186,'Stop 186',222.12345678,-307.12345678),(187,'Stop 187',223.12345678,-308.12345678),(188,'Stop 188',224.12345678,-309.12345678),(189,'Stop 189',225.12345678,-310.12345678),(190,'Stop 190',226.12345678,-311.12345678),(191,'Stop 191',227.12345678,-312.12345678),(192,'Stop 192',228.12345678,-313.12345678),(193,'Stop 193',229.12345678,-314.12345678),(194,'Stop 194',230.12345678,-315.12345678),(195,'Stop 195',231.12345678,-316.12345678),(196,'Stop 196',232.12345678,-317.12345678),(197,'Stop 197',233.12345678,-318.12345678),(198,'Stop 198',234.12345678,-319.12345678),(199,'Stop 199',235.12345678,-320.12345678),(200,'Stop 200',236.12345678,-321.12345678),(201,'Stop 201',237.12345678,-322.12345678),(202,'Stop 202',238.12345678,-323.12345678),(203,'Stop 203',239.12345678,-324.12345678),(204,'Stop 204',240.12345678,-325.12345678),(205,'Stop 205',241.12345678,-326.12345678),(206,'Stop 206',242.12345678,-327.12345678),(207,'Stop 207',243.12345678,-328.12345678),(208,'Stop 208',244.12345678,-329.12345678),(209,'Stop 209',245.12345678,-330.12345678),(210,'Stop 210',246.12345678,-331.12345678),(211,'Stop 211',247.12345678,-332.12345678),(212,'Stop 212',248.12345678,-333.12345678),(213,'Stop 213',249.12345678,-334.12345678),(214,'Stop 214',250.12345678,-335.12345678),(215,'Stop 215',251.12345678,-336.12345678),(216,'Stop 216',252.12345678,-337.12345678),(217,'Stop 217',253.12345678,-338.12345678),(218,'Stop 218',254.12345678,-339.12345678),(219,'Stop 219',255.12345678,-340.12345678),(220,'Stop 220',256.12345678,-341.12345678);
/*!40000 ALTER TABLE `stop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stopschedule`
--

DROP TABLE IF EXISTS `stopschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stopschedule` (
  `stop_id` int NOT NULL,
  `schedule_id` int NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_time` time NOT NULL,
  PRIMARY KEY (`stop_id`,`schedule_id`),
  KEY `fk_schedule_id` (`schedule_id`),
  CONSTRAINT `fk_schedule_id` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_stop_id2` FOREIGN KEY (`stop_id`) REFERENCES `stop` (`stop_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stopschedule`
--

LOCK TABLES `stopschedule` WRITE;
/*!40000 ALTER TABLE `stopschedule` DISABLE KEYS */;
INSERT INTO `stopschedule` VALUES (1,1,'10:00:00','10:15:00'),(1,2,'11:30:00','11:45:00'),(1,11,'10:15:00','10:30:00'),(1,21,'10:45:00','11:00:00'),(1,31,'10:20:00','10:40:00'),(1,41,'10:25:00','10:45:00'),(1,51,'09:40:00','09:50:00'),(1,61,'09:50:00','10:00:00'),(1,71,'10:10:00','10:20:00'),(1,81,'10:30:00','10:40:00'),(1,91,'10:00:00','10:10:00'),(1,101,'10:20:00','10:30:00'),(2,1,'10:30:00','10:45:00'),(2,2,'12:00:00','12:15:00'),(2,12,'11:20:00','11:40:00'),(2,22,'11:50:00','12:10:00'),(2,32,'11:30:00','11:50:00'),(2,42,'11:35:00','11:55:00'),(2,52,'10:40:00','10:50:00'),(2,62,'10:50:00','11:00:00'),(2,72,'11:10:00','11:20:00'),(2,82,'11:30:00','11:40:00'),(2,92,'11:00:00','11:10:00'),(2,102,'11:20:00','11:30:00'),(3,1,'11:00:00','11:15:00'),(3,2,'12:30:00','12:45:00'),(3,13,'12:35:00','12:50:00'),(3,23,'12:55:00','13:10:00'),(3,33,'12:40:00','13:00:00'),(3,43,'12:45:00','13:05:00'),(3,53,'11:40:00','11:50:00'),(3,63,'11:50:00','12:00:00'),(3,73,'12:10:00','12:20:00'),(3,83,'12:30:00','12:40:00'),(3,93,'12:00:00','12:10:00'),(3,103,'12:20:00','12:30:00'),(4,1,'11:30:00','11:45:00'),(4,2,'13:00:00','13:15:00'),(4,14,'13:45:00','14:00:00'),(4,24,'13:55:00','14:10:00'),(4,34,'13:50:00','14:10:00'),(4,44,'13:55:00','14:15:00'),(4,54,'12:40:00','12:50:00'),(4,64,'12:50:00','13:00:00'),(4,74,'13:10:00','13:20:00'),(4,84,'13:30:00','13:40:00'),(4,94,'13:00:00','13:10:00'),(4,104,'13:20:00','13:30:00'),(5,1,'12:00:00','12:15:00'),(5,2,'13:30:00','13:45:00'),(5,15,'14:55:00','15:15:00'),(5,25,'14:50:00','15:10:00'),(5,35,'14:55:00','15:15:00'),(5,45,'15:00:00','15:20:00'),(5,55,'13:40:00','13:50:00'),(5,65,'13:50:00','14:00:00'),(5,75,'14:10:00','14:20:00'),(5,85,'14:30:00','14:40:00'),(5,95,'14:00:00','14:10:00'),(5,105,'14:20:00','14:30:00'),(6,16,'15:50:00','16:10:00'),(6,26,'15:55:00','16:15:00'),(6,36,'15:55:00','16:15:00'),(6,46,'16:00:00','16:20:00'),(6,56,'14:40:00','14:50:00'),(6,66,'14:50:00','15:00:00'),(6,76,'15:10:00','15:20:00'),(6,86,'15:30:00','15:40:00'),(6,96,'15:00:00','15:10:00'),(6,106,'15:20:00','15:30:00'),(7,17,'16:40:00','17:00:00'),(7,27,'16:45:00','17:05:00'),(7,37,'16:55:00','17:15:00'),(7,47,'17:00:00','17:20:00'),(7,57,'15:40:00','15:50:00'),(7,67,'15:50:00','16:00:00'),(7,77,'16:10:00','16:20:00'),(7,87,'16:30:00','16:40:00'),(7,97,'16:00:00','16:10:00'),(7,107,'16:20:00','16:30:00'),(8,18,'17:55:00','18:15:00'),(8,28,'17:50:00','18:10:00'),(8,38,'17:50:00','18:10:00'),(8,48,'18:05:00','18:25:00'),(8,58,'16:40:00','16:50:00'),(8,68,'16:50:00','17:00:00'),(8,78,'17:10:00','17:20:00'),(8,88,'17:30:00','17:40:00'),(8,98,'17:00:00','17:10:00'),(8,108,'17:20:00','17:30:00'),(9,19,'18:50:00','19:10:00'),(9,29,'18:55:00','19:15:00'),(9,39,'18:55:00','19:15:00'),(9,49,'19:10:00','19:30:00'),(9,59,'17:40:00','17:50:00'),(9,69,'17:50:00','18:00:00'),(9,79,'18:10:00','18:20:00'),(9,89,'18:30:00','18:40:00'),(9,99,'18:00:00','18:10:00'),(9,109,'18:20:00','18:30:00'),(10,20,'19:45:00','20:05:00'),(10,30,'19:50:00','20:10:00'),(10,40,'19:55:00','20:15:00'),(10,50,'20:15:00','20:35:00'),(10,60,'18:40:00','18:50:00'),(10,70,'18:50:00','19:00:00'),(10,80,'19:10:00','19:20:00'),(10,90,'19:30:00','19:40:00'),(10,100,'19:00:00','19:10:00'),(10,110,'19:20:00','19:30:00');
/*!40000 ALTER TABLE `stopschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket` (
  `ticket_id` int NOT NULL,
  `passenger_id` int NOT NULL,
  `fare_type_id` int NOT NULL,
  `schedule_id` int NOT NULL,
  `purchase_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `fk_passenger_id2` (`passenger_id`),
  KEY `fk_fare_type_id2` (`fare_type_id`),
  KEY `fk_schedule_id2` (`schedule_id`),
  CONSTRAINT `fk_fare_type_id2` FOREIGN KEY (`fare_type_id`) REFERENCES `faretype` (`fare_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_passenger_id2` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_schedule_id2` FOREIGN KEY (`schedule_id`) REFERENCES `schedule` (`schedule_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (1,1,1,1,'2023-05-01',10.00),(2,2,2,2,'2023-05-02',15.00),(3,3,3,3,'2023-05-03',12.50),(4,4,4,4,'2023-05-04',8.00),(5,5,5,5,'2023-05-05',20.00),(6,6,6,6,'2023-05-06',17.50),(7,7,1,7,'2023-05-07',10.00),(8,8,2,8,'2023-05-08',15.00),(9,9,3,9,'2023-05-09',12.50),(10,10,4,10,'2023-05-10',8.00),(11,11,5,11,'2023-05-11',20.00),(12,12,6,12,'2023-05-12',17.50),(13,13,1,13,'2023-05-13',10.00),(14,14,2,14,'2023-05-14',15.00),(15,15,3,15,'2023-05-15',12.50),(16,16,4,16,'2023-05-16',8.00),(17,17,5,17,'2023-05-17',20.00),(18,18,6,18,'2023-05-18',17.50),(19,19,1,19,'2023-05-19',10.00),(20,20,2,20,'2023-05-20',15.00),(21,21,3,21,'2023-05-21',12.50),(22,22,4,22,'2023-05-22',8.00),(23,23,5,23,'2023-05-23',20.00),(24,24,6,24,'2023-05-24',17.50),(25,25,1,25,'2023-05-25',10.00),(26,26,2,26,'2023-05-26',15.00),(27,27,3,27,'2023-05-27',12.50),(28,28,4,28,'2023-05-28',8.00),(29,29,5,29,'2023-05-29',20.00),(30,30,6,30,'2023-05-30',17.50),(31,31,1,31,'2023-05-31',10.00),(32,32,2,32,'2023-06-01',15.00),(33,33,3,33,'2023-06-02',12.50),(34,34,4,34,'2023-06-03',8.00),(35,35,5,35,'2023-06-04',20.00),(36,36,6,36,'2023-06-05',17.50),(37,37,1,37,'2023-06-06',10.00),(38,38,2,38,'2023-06-07',15.00),(39,39,3,39,'2023-06-08',12.50),(40,40,4,40,'2023-06-09',8.00),(41,5,1,41,'2023-06-10',10.00),(42,6,2,42,'2023-06-11',15.00),(43,7,3,43,'2023-06-12',12.50),(44,8,4,44,'2023-06-13',8.00),(45,9,5,45,'2023-06-14',20.00),(46,10,6,46,'2023-06-15',17.50),(47,11,1,47,'2023-06-16',10.00),(48,12,2,48,'2023-06-17',15.00),(49,13,3,49,'2023-06-18',12.50),(50,14,4,50,'2023-06-19',8.00),(51,15,5,51,'2023-06-20',20.00),(52,16,6,52,'2023-06-21',17.50),(53,17,1,53,'2023-06-22',10.00),(54,18,2,54,'2023-06-23',15.00),(55,19,3,55,'2023-06-24',12.50),(56,20,4,56,'2023-06-25',8.00),(57,21,5,57,'2023-06-26',20.00),(58,22,6,58,'2023-06-27',17.50),(59,23,1,59,'2023-06-28',10.00),(60,24,2,60,'2023-06-29',15.00),(61,25,3,61,'2023-06-30',12.50),(62,26,4,62,'2023-07-01',8.00),(63,27,5,63,'2023-07-02',20.00),(64,28,6,64,'2023-07-03',17.50),(65,29,1,65,'2023-07-04',10.00),(66,30,2,66,'2023-07-05',15.00),(67,31,3,67,'2023-07-06',12.50),(68,32,4,68,'2023-07-07',8.00),(69,33,5,69,'2023-07-08',20.00),(70,34,6,70,'2023-07-09',17.50),(71,35,1,71,'2023-07-10',10.00),(72,36,2,72,'2023-07-11',15.00),(73,37,3,73,'2023-07-12',12.50),(74,38,4,74,'2023-07-13',8.00),(75,39,5,75,'2023-07-14',20.00),(76,40,6,76,'2023-07-15',17.50),(77,41,1,77,'2023-07-16',10.00),(78,42,2,78,'2023-07-17',15.00),(79,43,3,79,'2023-07-18',12.50),(80,44,4,80,'2023-07-19',8.00),(81,45,5,81,'2023-07-20',20.00),(82,46,6,82,'2023-07-21',17.50),(83,47,1,83,'2023-07-22',10.00),(84,48,2,84,'2023-07-23',15.00),(85,49,3,85,'2023-07-24',12.50),(86,50,4,86,'2023-07-25',8.00),(87,51,5,87,'2023-07-26',20.00),(88,52,6,88,'2023-07-27',17.50),(89,53,1,89,'2023-07-28',10.00),(90,54,2,90,'2023-07-29',15.00),(91,55,3,91,'2023-07-30',12.50),(92,56,4,92,'2023-07-31',8.00),(93,57,5,93,'2023-08-01',20.00),(94,58,6,94,'2023-08-02',17.50),(95,59,1,95,'2023-08-03',10.00),(96,60,2,96,'2023-08-04',15.00),(97,61,3,97,'2023-08-05',12.50),(98,62,4,98,'2023-08-06',8.00),(99,63,5,99,'2023-08-07',20.00),(100,64,6,100,'2023-08-08',17.50),(101,65,1,101,'2023-08-09',10.00),(102,66,2,102,'2023-08-10',15.00),(103,67,3,103,'2023-08-11',12.50),(104,68,4,104,'2023-08-12',8.00),(105,69,5,105,'2023-08-13',20.00),(106,70,6,106,'2023-08-14',17.50),(107,71,1,107,'2023-08-15',10.00),(108,72,2,108,'2023-08-16',15.00),(109,73,3,109,'2023-08-17',12.50),(110,74,4,110,'2023-08-18',8.00);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle` (
  `vehicle_id` int NOT NULL,
  `manufacturer` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `capacity` int NOT NULL,
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle`
--

LOCK TABLES `vehicle` WRITE;
/*!40000 ALTER TABLE `vehicle` DISABLE KEYS */;
INSERT INTO `vehicle` VALUES (1,'Toyota','Camry',5),(2,'Honda','Accord',5),(3,'Ford','Mustang',4),(4,'Chevrolet','Silverado',3),(5,'Tesla','Model S',4),(6,'AC','ACE',2),(7,'Abarth','Model 6',5),(8,'Acura','NSX',2),(9,'Alfa Romeo','Giulia',5),(10,'Alpine','A110',2),(11,'Alvis','Speed25',4),(12,'AMC','Gremlin',4),(13,'Ariel','Atom',2),(14,'Artega','GT',2),(15,'Ascari','KZ1',2),(16,'Aspid','GT17',4),(17,'Aston Martin','Vantage',2),(18,'Audi','Q5',5),(19,'Austin','Mini 4',4),(20,'Autobianchi','A112',4),(21,'Autocar','Type XV',4),(22,'Autozam','AZ-1',2),(23,'Avanti','II',2),(24,'BAC','Mono',1),(25,'Barkas','B1000',6),(26,'Bedelia','Type A',2),(27,'Bell Aurens','Longnose',4),(28,'Bitter','Vero',2),(29,'Bizzarrini','P538',2),(30,'Bond','Bug',2),(31,'Borgward','Isabella',4),(32,'Brabus','850',2),(33,'Bricklin','SV-1',2),(34,'Bristol','Fighter',2),(35,'Brooke','Doublle R',4),(36,'Bugatti','Veyron',2),(37,'Buick','Regal',5),(38,'BYD','QIN',5),(39,'Cadillac','CTS',5),(40,'Callaway','Corvette',2),(41,'Caparo','T1',2),(42,'Carbodies','FX4',5),(43,'Caterham','Seven',2),(44,'Checker','Marathon',6),(45,'Chery','Marathaon',6),(46,'Chevrolet','Impala',5),(47,'Chrysler','Pacifica',7),(48,'Cisitalia','202',2),(49,'Citroën','DS',5),(50,'Cizeta','V16T',2),(51,'Classic','DS',5),(52,'Clenet','Series 1',2),(53,'Colt','T120',2),(54,'Consulier','GTP',2),(55,'Continental','Mark II',5),(56,'Convaircar','Model 118',2),(57,'Cord','810',5),(58,'Cottereau','Type V',2),(59,'Covini','C6W',2),(60,'Crocker','Crocker',2),(61,'Covini','C6W',2),(62,'Crossley','Crossley',5),(63,'Cunningham','C3',3),(64,'CWS','T-1',4),(65,'Dacia','Logan',5),(66,'Daewoo','Matiz',4),(67,'Daimler','SP250',2),(68,'Dallara','Stradale',2),(69,'Dangel','44',5),(70,'Darracq','Type L',4),(71,'Datsun','240Z',2),(72,'De Lorean','DMC-12',2),(73,'De Tomaso','Pantera',2),(74,'Delage','D8',4),(75,'Delahaye','135',4),(76,'Dellow','MK II',2),(77,'Denzel','1300',4),(78,'Desoto','Firedome',5),(79,'Diamond T','Model 80',2),(80,'DKW','F8',4),(81,'Dodge','Charger',5),(82,'Dolch','GT',2),(83,'Dolphin','1',2),(84,'Donkervoort','D8',2),(85,'DS Automobiles','DS7',5),(86,'Duesenberg','Model J4',4),(87,'Durant','Star',5),(88,'Eicher','E2',2),(89,'Elio Motors','P4',2),(90,'Elva','Courier',2),(91,'Elfin','MS8',2),(92,'BMW','X6',4),(93,'Enfield','8000',4),(94,'Equus','Bass 770',4),(95,'ERA','Mini',4),(96,'ERF','LV',2),(97,'Essex','Model 6',5),(98,'Excalibur','Phaeton',2),(99,'Farbio','GTS',2),(100,'Fargo','GTS',2),(101,'FAW','BESTURN',5),(102,'Federal','92',2),(103,'Ferrari','250',2),(104,'Fisker','Karma',4),(105,'Foden','S21',2),(106,'Frazer','M6',2),(107,'FSO','Polonez',4),(108,'Fuji','Model 1',2),(109,'GAZ','Volga',5),(110,'Geely','Emgrand',5),(111,'General Motors','Model 3',5),(112,'Genesis','Model 4',5),(113,'Geo','Model 8',3),(114,'GMC','Yukon',7),(115,'Renault','Model 6',4);
/*!40000 ALTER TABLE `vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicledriver`
--

DROP TABLE IF EXISTS `vehicledriver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicledriver` (
  `vehicle_id` int NOT NULL,
  `driver_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`vehicle_id`,`driver_id`),
  KEY `fk_driver_id_VehicleDriver` (`driver_id`),
  CONSTRAINT `fk_driver_id_VehicleDriver` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vehicle_id_VehicleDriver` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`vehicle_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicledriver`
--

LOCK TABLES `vehicledriver` WRITE;
/*!40000 ALTER TABLE `vehicledriver` DISABLE KEYS */;
INSERT INTO `vehicledriver` VALUES (1,1,'2023-01-01','2023-02-28'),(2,2,'2023-03-01','2023-03-31'),(3,3,'2023-04-01','2023-04-30'),(4,4,'2023-05-01','2023-05-31'),(5,5,'2023-06-01','2023-06-30'),(6,6,'2023-07-01','2023-07-31'),(7,7,'2023-08-01','2023-08-31'),(8,8,'2023-09-01','2023-09-30'),(9,9,'2023-10-01','2023-10-31'),(10,10,'2023-11-01','2023-11-30'),(11,11,'2023-12-01','2023-12-31'),(12,12,'2024-01-01','2024-01-31'),(13,13,'2024-02-01','2024-02-29'),(14,14,'2024-03-01','2024-03-31'),(15,15,'2024-04-01','2024-04-30'),(16,16,'2024-05-01','2024-05-31'),(17,17,'2024-06-01','2024-06-30'),(18,18,'2024-07-01','2024-07-31'),(19,19,'2024-08-01','2024-08-31'),(20,20,'2024-09-01','2024-09-30'),(21,21,'2024-10-01','2024-10-31'),(22,22,'2024-11-01','2024-11-30'),(23,23,'2024-12-01','2024-12-31'),(24,24,'2025-01-01','2025-01-31'),(25,25,'2025-02-01','2025-02-28'),(26,26,'2025-03-01','2025-03-31'),(27,27,'2025-04-01','2025-04-30'),(28,28,'2025-05-01','2025-05-31'),(29,29,'2025-06-01','2025-06-30'),(30,30,'2025-07-01','2025-07-31'),(31,31,'2025-08-01','2025-08-31'),(32,32,'2025-09-01','2025-09-30'),(33,33,'2025-10-01','2025-10-31'),(34,34,'2025-11-01','2025-11-30'),(35,35,'2025-12-01','2025-12-31'),(36,36,'2026-01-01','2026-01-31'),(37,37,'2026-02-01','2026-02-28'),(38,38,'2026-03-01','2026-03-31'),(39,39,'2026-04-01','2026-04-30'),(40,40,'2026-05-01','2026-05-31'),(41,41,'2026-06-01','2026-06-30'),(42,42,'2026-07-01','2026-07-31'),(43,43,'2026-08-01','2026-08-31'),(44,44,'2026-09-01','2026-09-30'),(45,45,'2026-10-01','2026-10-31'),(46,46,'2026-11-01','2026-11-30'),(47,47,'2026-12-01','2026-12-31'),(48,48,'2027-01-01','2027-01-31'),(49,49,'2027-02-01','2027-02-28'),(50,50,'2027-03-01','2027-03-31'),(51,51,'2027-04-01','2027-04-30'),(52,52,'2027-05-01','2027-05-31'),(53,53,'2027-06-01','2027-06-30'),(54,54,'2027-07-01','2027-07-31'),(55,55,'2027-08-01','2027-08-31'),(56,56,'2027-09-01','2027-09-30'),(57,57,'2027-10-01','2027-10-31'),(58,58,'2027-11-01','2027-11-30'),(59,59,'2027-12-01','2027-12-31'),(60,60,'2028-01-01','2028-01-31'),(61,61,'2028-02-01','2028-02-29'),(62,62,'2028-03-01','2028-03-31'),(63,63,'2028-04-01','2028-04-30'),(64,64,'2028-05-01','2028-05-31'),(65,65,'2028-06-01','2028-06-30'),(66,66,'2028-07-01','2028-07-31'),(67,67,'2028-08-01','2028-08-31'),(68,68,'2028-09-01','2028-09-30'),(69,69,'2028-10-01','2028-10-31'),(70,70,'2028-11-01','2028-11-30'),(71,71,'2028-12-01','2028-12-31'),(72,72,'2029-01-01','2029-01-31'),(73,73,'2029-02-01','2029-02-28'),(74,74,'2029-03-01','2029-03-31'),(75,75,'2029-04-01','2029-04-30'),(76,76,'2029-05-01','2029-05-31'),(77,77,'2029-06-01','2029-06-30'),(78,78,'2029-07-01','2029-07-31'),(79,79,'2029-08-01','2029-08-31'),(80,80,'2029-09-01','2029-09-30'),(81,81,'2029-10-01','2029-10-31'),(82,82,'2029-11-01','2029-11-30'),(83,83,'2029-12-01','2029-12-31'),(84,84,'2030-01-01','2030-01-31'),(85,85,'2030-02-01','2030-02-28'),(86,86,'2030-03-01','2030-03-31'),(87,87,'2030-04-01','2030-04-30'),(88,88,'2030-05-01','2030-05-31'),(89,89,'2030-06-01','2030-06-30'),(90,90,'2030-07-01','2030-07-31'),(91,91,'2030-08-01','2030-08-31'),(92,92,'2030-09-01','2030-09-30'),(93,93,'2030-10-01','2030-10-31'),(94,94,'2030-11-01','2030-11-30'),(95,95,'2030-12-01','2030-12-31'),(96,96,'2031-01-01','2031-01-31'),(97,97,'2031-02-01','2031-02-28'),(98,98,'2031-03-01','2031-03-31'),(99,99,'2031-04-01','2031-04-30'),(100,100,'2031-05-01','2031-05-31'),(101,101,'2031-06-01','2031-06-30'),(102,102,'2031-07-01','2031-07-31'),(103,103,'2031-08-01','2031-08-31'),(104,104,'2031-09-01','2031-09-30'),(105,105,'2031-10-01','2031-10-31'),(106,106,'2031-11-01','2031-11-30'),(107,107,'2031-12-01','2031-12-31'),(108,108,'2032-01-01','2032-01-31'),(109,109,'2032-02-01','2032-02-29'),(110,110,'2032-03-01','2032-03-31'),(111,111,'2032-04-01','2032-04-30'),(112,112,'2032-05-01','2032-05-31'),(113,113,'2032-06-01','2032-06-30'),(114,114,'2032-07-01','2032-07-31'),(115,115,'2032-08-01','2032-08-31');
/*!40000 ALTER TABLE `vehicledriver` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-21 22:21:09
